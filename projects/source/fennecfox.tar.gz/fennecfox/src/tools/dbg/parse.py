#!/usr/bin/python

import sys

node_id = 0
layer = 0
time = 0
d1 = 0
d2 = 0
d3 = 0
d4 = 0
d5 = 0

f = open(sys.argv[1], "r")


for line in f.readlines():
	l = line.split()
	if len(l) < 24:
		continue;
	# 0-7 header
	# ignore
	node_id = int("%s%s"%(l[8],l[9]), 16)
	layer = int("%s%s"%(l[10],l[11]), 16) 
	time = int("%s%s"%(l[12],l[13]), 16) 
	d1 = int("%s%s"%(l[14],l[15]), 16) 
	d2 = int("%s%s"%(l[16],l[17]), 16) 
	d3 = int("%s%s"%(l[18],l[19]), 16) 
	d4 = int("%s%s"%(l[20],l[21]), 16) 
	d5 = int("%s%s"%(l[22],l[23]), 16) 
	print "Node %d Layer %d Time %d - %d %d %d %d %d"%(node_id, layer, time, d1, d2, d3, d4, d5)
