#!/usr/bin/python

import sys

node_id = 0
layer = 0
time = 0
d1 = 0
d2 = 0
d3 = 0
d4 = 0
d5 = 0

f = open(sys.argv[1], "r")


for line in f.readlines():
	l = line.split()
	if len(l) < 24:
		continue;
	# 0-7 header
	# ignore
	k_time = int(l[1])
	node_id = int("%s%s"%(l[10],l[11]), 16)
	layer = int("%s%s"%(l[12],l[13]), 16) 
	time = int("%s%s"%(l[14],l[15]), 16) 
	d1 = int("%s%s"%(l[16],l[17]), 16) 
	d2 = int("%s%s"%(l[18],l[19]), 16) 
	d3 = int("%s%s"%(l[20],l[21]), 16) 
	d4 = int("%s%s"%(l[22],l[23]), 16) 
	d5 = int("%s%s"%(l[24],l[25]), 16) 

	print "Node: %d"%(node_id),
	print "KTime: %d FTime: %d"%(k_time, time),

	if layer == 1:
		print "Layer: Application",
                if d1 == 0:
                        print "sending: offset %d"%(d2),

                if d1 == 1:
                        print "start receiving"%(),
                
                if d1 == 2:
                        print "received: counter %d offset %d start %d end %d"%(d2, d3, d4, d5),

	if layer == 2:
		print "Layer: Network",
                if d1 == 0:
                        print "start protocol",

                if d1 == 99:
                        print "stop prototocol",

		if d1 == 1:
			print "sending to %s"%(str(0)),

		if d1 == 2 and d2 == 1:
			print "receive discover",
               
		if d1 == 2 and d2 == 2:
			print "receive bridge reply",

		if d1 == 2 and d2 == 3:
			print "receive bridge reply failed",
 
		if d1 == 2 and d2 == 4:
			print "receive pre_check",

		if d1 == 2 and d2 == 5:
			print "receive data",

		if d1 == 2 and d2 == 6:
			print "receive don't know",

                if d1 == 3:
                        print "send discover",

                if d1 == 4:
                        print "forward to %d"%(d2),

	if layer == 3:
		print "Layer: QoI", 

	if layer == 4:
		print "Layer: Mac",

	if layer == 5:
		print "Layer: Radio", 

	if layer == 6:
		print "Layer: Events",

	if layer == 7:
		print "Layer: Engine",

                if d1 == 1 and d2 == 1:
                        print "starts application",

                if d1 == 1 and d2 == 99:
                        print "stops application",

                if d1 == 2 and d2 == 1:
                        print "starts network",

                if d1 == 2 and d2 == 99:
                        print "stops network",

                if d1 == 3 and d2 == 1:
                        print "starts qoi",

                if d1 == 3 and d2 == 99:
                        print "stops qoi",

                if d1 == 4 and d2 == 1:
                        print "starts mac",

                if d1 == 4 and d2 == 99:
                        print "stops mac",

                if d1 == 5 and d2 == 1:
                        print "starts radio",

                if d1 == 5 and d2 == 99:
                        print "stops radio",

                if d1 == 6 and d2 == 1:
                        print "starts events",

                if d1 == 6 and d2 == 99:
                        print "stops events",

                if d1 == 7 and d2 == 1:
                        print "starts engine",

                if d1 == 7 and d2 == 99:
                        print "stops engine",



	if layer == 9:
		print "Layer: Policy",
		if d1 == 3:
			print "force new conf # %d seq is %d"%(d2, d3),

		if d1 == 1:
			print "got first time conf: old %d new %d"%(d2, d3),

		if d1 == 2:
			print "got newer conf: old %d new %d"%(d2, d3),

	print
