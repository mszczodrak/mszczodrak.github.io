#!/usr/bin/python

import sys
import os
from operator import itemgetter, attrgetter


allLines = []

for afile in os.listdir(sys.argv[1]):

	f = open("%s/%s"%(sys.argv[1],afile), "r")

	for line in f.readlines():
		l = line.split()

	        if len(l) < 24:
	                continue
		
		newL = []
		newL.append(int(l[0]))
		newL.append(int(l[1]))
		t = int("%s%s"%(l[10],l[11]), 16)
		newL.append(t)
		t = int("%s%s"%(l[12],l[13]), 16)
		newL.append(t)
		t = int("%s%s"%(l[14],l[15]), 16)
		newL.append(t)
		t = int("%s%s"%(l[16],l[17]), 16)
		newL.append(t)
		t = int("%s%s"%(l[18],l[19]), 16)
		newL.append(t)
		t = int("%s%s"%(l[20],l[21]), 16)
		newL.append(t)
		t = int("%s%s"%(l[22],l[23]), 16)
		newL.append(t)
		t = int("%s%s"%(l[24],l[25]), 16)
		newL.append(t)

		allLines.append(newL)

	f.close()

sLines = sorted(allLines, key=itemgetter(1)) 


fout = open("temp_output.txt", 'w')
for line in sLines:
	for w in line:
		fout.write("%s "%w)
	fout.write("\n")
fout.close()

fin = open("temp_output.txt", 'r')
fout = open("results.txt", 'w')
for line in fin.readlines():
	l = line.split()
        k_time = int(l[1])
        node_id = int(l[2])
        layer = int(l[3])
        time = int(l[4])
        d1 = int(l[5])
        d2 = int(l[6])
        d3 = int(l[7])
        d4 = int(l[8])
        d5 = int(l[9])

        fout.write("Node: %3d "%(node_id))
        fout.write("KTime: %8d FTime: %8d "%(k_time, time))

        if layer == 1:
                fout.write("Layer: Application ")
                if d1 == 0:
                        fout.write("sending: offset %2d "%(d2))

                if d1 == 1:
                        fout.write("start receiving "%())

                if d1 == 2:
                        fout.write("received: counter %3d offset %3d start %8d end %8d "%(d2, d3, d4, d5))

        if layer == 2:
                fout.write("Layer: Network     ")
                if d1 == 0:
                        fout.write("start protocol ")

                if d1 == 99:
                        fout.write("stop prototocol ")

                if d1 == 1:
                        fout.write("sending to %s "%(str(0)))

                if d1 == 2 and d2 == 1:
                        fout.write("receive discover ")

                if d1 == 2 and d2 == 2:
                        fout.write("receive bridge reply ")

                if d1 == 2 and d2 == 3:
                        fout.write("receive bridge reply failed ")

                if d1 == 2 and d2 == 4:
                        fout.write("receive pre_check ")

                if d1 == 2 and d2 == 5:
                        fout.write("receive data ")

                if d1 == 2 and d2 == 6:
                        fout.write("receive don't know ")

                if d1 == 3:
                        fout.write("send discover ")

                if d1 == 4:
                        fout.write("forward to %d "%(d2))

        if layer == 3:
                fout.write("Layer: QoI         ")

        if layer == 4:
                fout.write("Layer: Mac         ")

        if layer == 5:
                fout.write("Layer: Radio       ")

        if layer == 6:
                fout.write("Layer: Events      ")

        if layer == 7:
                fout.write("Layer: Engine      ")

                if d1 == 1 and d2 == 1:
                        fout.write("starts application ")

                if d1 == 1 and d2 == 99:
                        fout.write("stops application ")

                if d1 == 2 and d2 == 1:
                        fout.write("starts network ")

                if d1 == 2 and d2 == 99:
                        fout.write("stops network ")

                if d1 == 3 and d2 == 1:
                        fout.write("starts qoi ")

                if d1 == 3 and d2 == 99:
                        fout.write("stops qoi ")

                if d1 == 4 and d2 == 1:
                        fout.write("starts mac ")

                if d1 == 4 and d2 == 99:
                        fout.write("stops mac ")

                if d1 == 5 and d2 == 1:
                        fout.write("starts radio ")

                if d1 == 5 and d2 == 99:
                        fout.write("stops radio ")

                if d1 == 6 and d2 == 1:
                        fout.write("starts events ")

                if d1 == 6 and d2 == 99:
                        fout.write("stops events ")

                if d1 == 7 and d2 == 1:
                        fout.write("starts engine ")

                if d1 == 7 and d2 == 99:
                        fout.write("stops engine ")



        if layer == 9:
                fout.write("Layer: Policy      ")
                if d1 == 3:
                        fout.write("force new conf # %d seq is %d "%(d2, d3))

                if d1 == 1:
                        fout.write("got first time conf: old %d new %d "%(d2, d3))

                if d1 == 2:
                        fout.write("got newer conf: old %d new %d "%(d2, d3))

		if d1 == 4:
			fout.write("event occured - new conf is %d "%(d2))

	fout.write("\n")

fout.close()


