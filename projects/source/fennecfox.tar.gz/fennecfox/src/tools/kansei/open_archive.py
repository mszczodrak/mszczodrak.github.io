#!/usr/bin/python

import sys
import os

class OpenArchive:
	def __init__(self, archName):
		self.name = archName
		self.num = archName.split('_')[1].split(".")[0]
		os.system("tar -zxvf %s"%(self.name))
		os.system("rm -rf test_%s"%(self.num))
		os.mkdir("test_%s"%(self.num))
	
		for dirname, dirnames, filenames in os.walk("./output"):
			for afile in filenames:
				if afile.split(".")[1] == 'tgz':
					os.system("tar -zxvf %s/%s"%(dirname,afile))
					

		os.system("mv asflog-*.txt test_%s"%(self.num))
		os.system("rm -rf output")
		os.system("rm job.log t2_log.txt")

	def prepare(self):
		pass


if __name__ == "__main__":

	if len(sys.argv) == 2:
		oa = OpenArchive(sys.argv[1])
		oa.prepare()
	



