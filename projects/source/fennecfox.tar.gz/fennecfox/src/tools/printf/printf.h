#ifndef PRINTF_H
#define PRINTF_H

#ifndef PRINTF_BUF_SIZE
 #define PRINTF_BUF_SIZE 100
#endif

#ifdef _H_msp430hardware_h
   #include <stdio.h>
#else
   #ifdef _H_atmega128hardware_H
      #include "avr_stdio.h"
   #else
      #ifdef __M16C62PHARDWARE_H__ 
         #include "m16c62p_printf.h"
      #else
         #include "generic_printf.h"
      #endif
   #endif
#endif

int printfflush();

#endif

