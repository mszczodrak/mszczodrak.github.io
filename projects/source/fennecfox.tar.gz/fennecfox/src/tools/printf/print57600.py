#!/usr/bin/python

import serial
import sys
import string

class Mote:

  def __init__(self):
    self.dev = '/dev/ttyUSB1'
    self.bound = 57600
    self.timeout = 1
    self.buf = []
    self.s = serial.Serial(self.dev, self.bound, timeout = self.timeout)

    self.busy = 0

    self.run()


  def run(self):
  
    while 1:
      sin = self.s.read(5)
      if len(sin) > 0:
        filtered_string = filter(lambda x: x in string.printable, sin)
        sys.stdout.write(filtered_string)



if __name__ == "__main__":
  s = Mote()

