#ifndef __H_SIMPLE_CC2420_
#define __H_SIMPLE_CC2420_

#include "CC2420.h"

enum {
        SIMPLE_CC2420_MIN_MESSAGE_SIZE        	= 5,
        SIMPLE_CC2420_MAX_MESSAGE_SIZE        	= 127,
	SIMPLE_CC2420_FIRST			= 1,
};

#endif
