#ifndef _TINYOS_RADIO_H
#define _TINYOS_RADIO_H

enum {
        TINYOS_MIN_MESSAGE_SIZE        = 10,
        TINYOS_MAX_MESSAGE_SIZE        = 127,
	TINYOS_RADIO_MAX_BUSY_LENGTH = 100,
};

#endif
