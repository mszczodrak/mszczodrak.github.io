#ifndef _RAW_SERIAL_H_
#define _RAW_SERIAL_H_

typedef struct raw_serial_header_t{
  uint32_t len;
} raw_serial_header_t;

#endif 


