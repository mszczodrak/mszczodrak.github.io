#ifndef _SEND_TEMP_H
#define _SEND_TEMP_H

typedef nx_struct {
   nx_uint16_t counter;
   nx_uint16_t value;
} temp_msg_t;

#endif

