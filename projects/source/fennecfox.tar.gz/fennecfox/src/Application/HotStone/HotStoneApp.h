#ifndef _HOT_STONE_H
#define _HOT_STONE_H

#define EXTRA_SIZE 0

typedef nx_struct {
   nx_uint16_t counter;
} hot_stone_msg_t;

#endif

