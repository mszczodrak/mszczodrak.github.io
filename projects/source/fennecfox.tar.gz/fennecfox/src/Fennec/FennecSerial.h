#ifndef FENNEC_SERIAL_COMMANDS_H
#define FENNEC_SERIAL_COMMANDS_H

nx_struct fdbg {
    nx_uint16_t id;
    nx_uint8_t layer;
    nx_uint8_t d1;
    nx_uint8_t d2;
    nx_uint8_t d3;
    nx_uint8_t d4;
    nx_uint8_t d5;
};


nx_struct fennec_serial_command {
  nx_uint8_t type;
};

enum {
	FORCE_NEW_CONFIGURATION		= 1,
	GET_FENNEC_STATUS_FLAG		= 2,
	SET_BRIDGE_FLAG			= 3,
	UNSET_BRIDGE_FLAG		= 4,
	ADD_ACCEPT_CONFIGURATION	= 5,
};

#endif
