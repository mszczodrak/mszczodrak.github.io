/*
 * Copyright (c) 2008-2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * author: Marcin Szczodrak
 * date:   1/1/2011
 */

#ifndef FENNEC_H
#define FENNEC_H

#ifdef FENNEC_TOS_PRINTF
#define NEW_PRINTF_SEMANTICS
#include "printf.h"
#endif

nx_struct fennec_header {
  nx_uint8_t len;
  nx_uint8_t conf;
};

typedef nx_struct msg_t {
  nx_uint8_t data[128];
  nx_uint8_t len;
  nx_uint16_t next_hop;
  nx_uint8_t ack;
  nx_struct fennec_header fennec;
  nx_uint8_t channel;
  nx_uint8_t vnet_id;
  nx_uint8_t last_layer;
  nx_uint8_t rssi;
  nx_uint8_t lqi;
} msg_t;

nx_struct FFControl {
  /* source of the of the configuration - variable based on Addressing */
  nx_uint16_t crc;
  nx_uint16_t seq;            /* sequence number of the configuration */
  nx_uint8_t vnet_id;         /* virtual network id */
  nx_uint8_t conf_id;
  nx_uint8_t accepts;         /* number of new additional accepting configurations */
  /* array of new accepts */
};

nx_struct fennec_configuration {
  nx_uint8_t application;
  nx_uint8_t network;
  nx_uint8_t net_addr;
  nx_uint8_t qoi;
  nx_uint8_t mac;
  nx_uint8_t mac_addr;
  nx_uint8_t radio;
};

struct configuration_cache {
  uint8_t *app;
  uint32_t app_len;
  uint8_t *net;
  uint32_t net_len;
  uint8_t *qoi;
  uint32_t qoi_len;
  uint8_t *mac;
  uint32_t mac_len;
  uint8_t *radio;
  uint32_t radio_len;
};

nx_struct fennec_policy {
  nxle_uint8_t  src_conf;
  nxle_uint16_t event_mask;
  nxle_uint8_t  dst_conf;
};

nx_struct fennec_event {
  nx_uint8_t operation;
  nx_uint16_t value;
};

nx_struct accept_conf {
  nx_struct fennec_header fennec;
  nx_uint8_t vnet_id;
  nx_uint8_t local_conf;
};

enum {
        OFF                     = 0,
        ON                      = 1,

        EQ                      = 1,
        NQ                      = 2,
        LT                      = 3,
        LE                      = 4,
        GT                      = 5,
        GE                      = 6,

        CONFIGURATION_PROT      = unique("DisseminationTimerC.TrickleTimer"),
        CONFIGURATION_SEQ_UNKNOWN = 0,
        CONFIGURATION_MSG       = 0,
        CONFIGURATION_PROBE     = 1,

        MESSAGE_CACHE_LEN       = 10,

	MAX_NUM_EVENTS		= 32,

	NUMBER_OF_ACCEPTING_CONFIGURATIONS = 10,
	ACCEPTING_RESEND	= 2,

        DEFAULT_FENNEC_SENSE_PERIOD = 1024,

	NODE			= 0xfffa,
        BRIDGE                  = 0xfffc,
        UNKNOWN                 = 0xfffd,
        MAX_COST                = 0xfffe,
        BROADCAST               = 0xffff,

	MAX_ADDR_LENGTH		= 8, 		/* in bytes */


	ANY			= 253,
        UNKNOWN_CONFIGURATION   = 254,
        UNKNOWN_LAYER           = 255,

        /* States */
        S_STOPPED               = 0,
        S_STARTING              = 1,
        S_STARTED               = 2,
        S_STOPPING              = 3,
        S_TRANSMITTING          = 4,
        S_LOADING               = 5,
        S_LOADED                = 6,
        S_CANCEL                = 7,
        S_ACK_WAIT              = 8,
        S_SAMPLE_CCA            = 9,
        S_SENDING_ACK           = 10,
        S_NOT_ACKED             = 11,
        S_BROADCASTING          = 12,
        S_HALTED                = 13,
        S_BRIDGE_DELAY          = 14,
        S_DISCOVER_DELAY        = 15,
        S_INIT        		= 16,
        S_SYNC       		= 17,
        S_SYNC_SEND       	= 18,
        S_SYNC_RECEIVE  	= 19,
	S_SEND_DONE		= 20,
	S_SLEEPING		,
	S_OPERATIONAL		,
	S_TURN_ON		,
	S_TURN_OFF		,
	S_PREAMBLE		,

                /* tx */
        S_SFD                   ,
        S_EFD                   ,

                /* rx */
        S_RX_LENGTH             ,
        S_RX_FCF                ,
        S_RX_PAYLOAD            ,


                /* Panic Levels */
        PANIC_OK                = 0,
        PANIC_DEAD              = 1,
        PANIC_WARNING           = 2,

                /* Fennec System Flags */
        F_RADIO                 = 1,
        F_ADDRESSING		= 2,
        F_MAC                   = 3,
        F_QOI                   = 4,
        F_NETWORK               = 5,
        F_APPLICATION           = 6,
        F_EVENTS                = 7,
        F_MAC_ADDRESSING	= 8,
        F_NETWORK_ADDRESSING	= 9,

        F_ENGINE                = 10,
	F_CONTROL_UNIT		= 11,
        F_PRINTING              = 12,
        F_SENDING               = 13,
        F_BRIDGING              = 14,
        F_DATA_SRC              = 15,
	F_NEW_ADDR		= 16,

	F_NODE			= 20,
	F_BRIDGE		= 21,
	F_BASE_STATION		= 22,

        FENNEC_SYSTEM_FLAGS_NUM = 30,
	POLICY_CONFIGURATION	= 250,
};

/* Forces a change in configuration */
void force_new_configuration(uint8_t new_conf);

#endif
