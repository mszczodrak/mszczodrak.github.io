#include <Fennec.h>

struct radio_class {
	error_t (*load) (msg_t *msg);
	error_t (*send) (msg_t *msg);
	error_t (*resend) (msg_t *msg);
	uint8_t (*sampleCCA) (msg_t *msg);
	uint8_t (*getPayload) (msg_t *msg);
	uint8_t (*getMaxSize) (msg_t *msg);
};
