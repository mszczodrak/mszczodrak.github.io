#ifndef _H_Timer_62500hz_h
#define _H_Timer_62500hz_h

typedef struct { } T62500hz;

#define UQ_ALARM_32KHZ32 "Virtual.32khz32Alarm"
#define UQ_ALARM_62500HZ32 "Virtual.62500hzAlarm"
#define UQ_TIMER_62500HZ "HilTimer62500hzC.Timer"
#endif

