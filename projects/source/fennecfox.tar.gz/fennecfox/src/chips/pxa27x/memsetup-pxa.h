#ifndef MEMSETUP_PXA_H
#define MEMSETUP_PXA_H
  extern void memsetup();
#endif //TOSH_HARDWARE_H
