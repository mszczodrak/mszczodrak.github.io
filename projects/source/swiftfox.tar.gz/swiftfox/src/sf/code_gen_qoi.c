/*
 * Copyright (c) 2010-2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateQoIC() {

  struct modtab *mp;
  FILE *fp_qoiC = fopen(qoiC, "w");

  if (fp_qoiC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", qoiC);
    exit(1);
  }

  fprintf(fp_qoiC, "/* Swift Fox generated code for Fennec Fox QoI configuration */\n");
  fprintf(fp_qoiC, "\n#include <Timer.h>\n\n");
  fprintf(fp_qoiC, "configuration QoIC {\n");
  fprintf(fp_qoiC, "  provides interface Mgmt;\n");
  fprintf(fp_qoiC, "}\n\n");
  fprintf(fp_qoiC, "implementation {\n\n");
  fprintf(fp_qoiC, "  components QoIP;\n");
  fprintf(fp_qoiC, "  Mgmt = QoIP;\n");
  fprintf(fp_qoiC, "  components CachesC;\n");
  fprintf(fp_qoiC, "  QoIP.ConfigurationCache -> CachesC;\n\n");
  fprintf(fp_qoiC, "  CachesC.QoI -> QoIP;\n\n");
  fprintf(fp_qoiC, "  /* Defined and linked network protocols */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_QOI) {
      fprintf(fp_qoiC, "\n  components new %sNetC%s as %s_%d_NetC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_qoiC, "  QoIP.%s_%d_Control -> %s_%d_NetC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_qoiC, "  CachesC.%s_%s_%d -> %s_%d_NetC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_qoiC, "\n}\n");
  fclose(fp_qoiC);
}

void generateQoIP() {

  struct modtab *mp;
  FILE *fp_qoiM = fopen(qoiM, "w");

  if (fp_qoiM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", qoiM);
    exit(1);
  }

  fprintf(fp_qoiM, "/* Swift Fox generated code for Fennec Fox QoI module */\n");
  fprintf(fp_qoiM, "\n#include <Fennec.h>\n");
  fprintf(fp_qoiM, "module QoIP {\n\n");
  fprintf(fp_qoiM, "  provides interface Mgmt;\n");
  fprintf(fp_qoiM, "  provides interface Module;\n");
  fprintf(fp_qoiM, "  uses interface ConfigurationCache;\n");
  fprintf(fp_qoiM, "  /* Defined and linked qoi protocols */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_QOI) {
      fprintf(fp_qoiM, "  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_qoiM,"}\n\n");
  fprintf(fp_qoiM,"implementation {\n\n");
  fprintf(fp_qoiM,"  uint8_t last_module_id;\n");
  fprintf(fp_qoiM,"  void setLibrary(bool flag);\n");
  fprintf(fp_qoiM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_qoiM,"    last_module_id = 0;\n");
  fprintf(fp_qoiM,"    setLibrary(ON);\n");
  fprintf(fp_qoiM,"    return SUCCESS;\n");
  fprintf(fp_qoiM,"  }\n\n");
  fprintf(fp_qoiM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_qoiM,"    last_module_id = 0;\n");
  fprintf(fp_qoiM,"    setLibrary(OFF);\n");
  fprintf(fp_qoiM,"    return SUCCESS;\n");
  fprintf(fp_qoiM,"  }\n\n");
  fprintf(fp_qoiM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_qoiM,"    last_module_id = call ConfigurationCache.next_module(F_NETWORK, last_module_id);\n");
  fprintf(fp_qoiM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_QOI) {
      fprintf(fp_qoiM, "      case %d:\n", mp->id);
      fprintf(fp_qoiM, "        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_qoiM, "        break;\n\n");
    }
  }

  fprintf(fp_qoiM,"      default:\n");
  fprintf(fp_qoiM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_qoiM,"    }\n");
  fprintf(fp_qoiM,"  }\n\n\n");


  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_QOI) {
      fprintf(fp_qoiM, "  event void %s_%d_Control.startDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_qoiM, "    setLibrary(ON);\n");
      fprintf(fp_qoiM, "  }\n");
      fprintf(fp_qoiM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_qoiM, "    setLibrary(OFF);\n");
      fprintf(fp_qoiM, "  }\n");
    }
  }

  fprintf(fp_qoiM, "\n}\n");
  fclose(fp_qoiM);
}

