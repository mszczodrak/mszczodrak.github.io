/*
 * Copyright (c) 2010-2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateMacC() {

  struct modtab *mp;
  FILE *fp_macC = fopen(macC, "w");

  if (fp_macC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", macC);
    exit(1);
  }

  fprintf(fp_macC, "/* Swift Fox generated code for Fennec Fox MAC configuration */\n");
  fprintf(fp_macC, "configuration MacC {\n");
  fprintf(fp_macC, "  provides interface Mgmt;\n");
  fprintf(fp_macC, "  provides interface MacCall;\n");
  fprintf(fp_macC, "  provides interface MacSignal;\n");
  fprintf(fp_macC, "}\n\n");
  fprintf(fp_macC, "implementation {\n\n");
  fprintf(fp_macC, "  components MacP;\n");
  fprintf(fp_macC, "  Mgmt = MacP;\n");
  fprintf(fp_macC, "  MacCall = MacP;\n");
  fprintf(fp_macC, "  MacSignal = MacP;\n\n");
  fprintf(fp_macC, "  components RadioC;\n");
  fprintf(fp_macC, "  MacP.RadioSignal -> RadioC;\n\n");
  fprintf(fp_macC, "  components CachesC;\n");
  fprintf(fp_macC, "  MacP.ConfigurationCache -> CachesC;\n\n");
  fprintf(fp_macC, "  CachesC.Mac -> MacP;\n\n");
  fprintf(fp_macC, "  /* Defined and linked mac protocols */\n");


  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macC, "\n  components new %sMacC%s as %s_%d_MacC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_macC, "  MacP.%s_%d_Control -> %s_%d_MacC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_macC, "  MacP.%s_%d_Call -> %s_%d_MacC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_macC, "  MacP.%s_%d_MacSignal -> %s_%d_MacC.MacSignal;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_macC, "  MacP.%s_%d_RadioSignal <- %s_%d_MacC.RadioSignal;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_macC, "  RadioC.RadioCall <- %s_%d_MacC.RadioCall;\n", mp->lib->name, mp->id);
      fprintf(fp_macC, "  CachesC.%s_%s_%d -> %s_%d_MacC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macC, "\n}\n");
  fclose(fp_macC);
}

void generateMacP() {

  struct modtab *mp;
  FILE *fp_macM = fopen(macM, "w");

  if (fp_macM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", macM);
    exit(1);
  }

  fprintf(fp_macM, "/* Swift Fox generated code for Fennec Fox MAC module */\n");
  fprintf(fp_macM, "\n#include <Fennec.h>\n");
  fprintf(fp_macM, "module MacP {\n\n");
  fprintf(fp_macM, "  provides interface Mgmt;\n");
  fprintf(fp_macM, "  provides interface Module;\n");
  fprintf(fp_macM, "  provides interface MacCall;\n");
  fprintf(fp_macM, "  provides interface MacSignal;\n");
  fprintf(fp_macM, "  uses interface ConfigurationCache;\n");
  fprintf(fp_macM, "  uses interface RadioSignal;\n\n");
  fprintf(fp_macM, "  /* Defined and linked mac protocols */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "\n  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "  uses interface MacCall as %s_%d_Call;\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "  uses interface MacSignal as %s_%d_MacSignal;\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "  provides interface RadioSignal as %s_%d_RadioSignal;\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"}\n\n");
  fprintf(fp_macM,"implementation {\n\n");
  fprintf(fp_macM,"  uint8_t last_module_id;\n");
  fprintf(fp_macM,"  void setLibrary(bool flag);\n");
  fprintf(fp_macM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_macM,"    last_module_id = 0;\n");
  fprintf(fp_macM,"    setLibrary(ON);\n");
  fprintf(fp_macM,"    return SUCCESS;\n");
  fprintf(fp_macM,"  }\n\n");
  fprintf(fp_macM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_macM,"    last_module_id = 0;\n");
  fprintf(fp_macM,"    setLibrary(OFF);\n");
  fprintf(fp_macM,"    return SUCCESS;\n");
  fprintf(fp_macM,"  }\n\n");
  fprintf(fp_macM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_macM,"    last_module_id = call ConfigurationCache.next_module(F_MAC, last_module_id);\n");
  fprintf(fp_macM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_macM, "        break;\n\n");
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");


  fprintf(fp_macM,"  command error_t MacCall.send(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    msg->last_layer = F_NETWORK;\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        return call %s_%d_Call.send(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return FAIL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");


  fprintf(fp_macM,"  command uint8_t* MacCall.getPayload(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        return call %s_%d_Call.getPayload(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return NULL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  fprintf(fp_macM,"  command error_t MacCall.ack(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, NULL)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM,"        return call %s_%d_Call.ack(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return FAIL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  fprintf(fp_macM,"  command uint8_t MacCall.getMaxSize(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, NULL)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        return call %s_%d_Call.getMaxSize(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return FAIL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  fprintf(fp_macM,"  command error_t MacCall.sniffing(bool flag, msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, NULL)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM,"        return call %s_%d_Call.sniffing(flag, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return FAIL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  fprintf(fp_macM,"  command uint8_t* MacCall.getSource(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM,"        return call %s_%d_Call.getSource(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return NULL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  fprintf(fp_macM,"  command uint8_t* MacCall.getDestination(msg_t *msg) {\n\n");
  fprintf(fp_macM,"    switch( call ConfigurationCache.get_protocol(F_MAC, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM,"        return call %s_%d_Call.getDestination(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return NULL;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM,"  }\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "  event void %s_%d_Control.startDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "    setLibrary(ON);\n");
      fprintf(fp_macM, "  }\n\n");
      fprintf(fp_macM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "    setLibrary(OFF);\n");
      fprintf(fp_macM, "  }\n\n");
      fprintf(fp_macM, "  event void %s_%d_MacSignal.sendDone(msg_t *msg, error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "    signal MacSignal.sendDone(msg, err);\n");
      fprintf(fp_macM, "  }\n\n");
      fprintf(fp_macM, "  event void %s_%d_MacSignal.receive(msg_t *msg, uint8_t* payload, uint8_t len) {\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "    signal MacSignal.receive(msg, payload, len);\n");
      fprintf(fp_macM, "  }\n\n");
    }
  }

  fprintf(fp_macM,"  void sendDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_macM,"    msg->last_layer = F_RADIO;\n");
  fprintf(fp_macM,"    msg->len -= sizeof(nx_struct fennec_header);\n\n");
  fprintf(fp_macM,"    switch (call ConfigurationCache.get_protocol(F_MAC, msg) ) {\n\n");
  fprintf(fp_macM,"      case 0:\n");
  fprintf(fp_macM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        signal %s_%d_RadioSignal.sendDone(msg, err);\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "        break;\n\n");
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        break;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM, "  }\n\n");

  fprintf(fp_macM,"  void loadDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_macM,"    msg->last_layer = F_RADIO;\n\n");
  fprintf(fp_macM,"    switch (call ConfigurationCache.get_protocol( F_MAC, msg) ) {\n\n");
  fprintf(fp_macM,"      case 0:\n");
  fprintf(fp_macM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        signal %s_%d_RadioSignal.loadDone(msg, err);\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "        break;\n\n");
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        break;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM, "  }\n\n");

  fprintf(fp_macM,"  void receive(msg_t *msg, uint8_t *payload, uint8_t len) {\n");
  fprintf(fp_macM,"    msg->last_layer = F_RADIO;\n");
  fprintf(fp_macM,"    msg->len -= sizeof(nx_struct fennec_header);\n");
  fprintf(fp_macM,"    len -= sizeof(nx_struct fennec_header);\n");
  fprintf(fp_macM,"    payload += sizeof(nx_struct fennec_header);\n\n");
  fprintf(fp_macM,"    switch (call ConfigurationCache.get_protocol(F_MAC, msg) ) {\n\n");
  fprintf(fp_macM,"      case 0:\n");
  fprintf(fp_macM,"        signal Module.drop_message(msg);\n\n");
  fprintf(fp_macM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        signal %s_%d_RadioSignal.receive(msg, payload, len);\n", mp->lib->name, mp->id);
      fprintf(fp_macM, "        break;\n\n");
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        signal Module.drop_message(msg);\n\n");
  fprintf(fp_macM,"        break;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM, "  }\n\n");

  fprintf(fp_macM,"  bool check_destination(msg_t *msg, uint8_t *payload) {\n");
  fprintf(fp_macM,"    switch (call ConfigurationCache.get_protocol(F_MAC , msg) ) {\n\n");
  fprintf(fp_macM,"      case 0:\n");
  fprintf(fp_macM,"        return FALSE;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_MAC) {
      fprintf(fp_macM, "      case %d:\n", mp->id);
      fprintf(fp_macM, "        return signal %s_%d_RadioSignal.check_destination(msg, payload);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_macM,"      default:\n");
  fprintf(fp_macM,"        return FALSE;\n");
  fprintf(fp_macM,"    }\n");
  fprintf(fp_macM, "  }\n\n");

  fprintf(fp_macM, "  event void RadioSignal.sendDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_macM, "    sendDone(msg, err);\n");
  fprintf(fp_macM, "  }\n\n");
  fprintf(fp_macM, "  event void RadioSignal.loadDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_macM, "    loadDone(msg, err);\n");
  fprintf(fp_macM, "  }\n\n");
  fprintf(fp_macM, "  event void RadioSignal.receive(msg_t *msg, uint8_t *payload, uint8_t len) {\n");
  fprintf(fp_macM, "    receive(msg, payload, len);\n");
  fprintf(fp_macM, "  }\n\n");
  fprintf(fp_macM, "  async event bool RadioSignal.check_destination(msg_t *msg, uint8_t *payload) {\n");
  fprintf(fp_macM, "    return check_destination(msg, payload);\n");
  fprintf(fp_macM, "  }\n\n");

  fprintf(fp_macM, "\n}\n");
  fclose(fp_macM);
}

