/*
 * Copyright (c) 2010-2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateRadioC() {

  struct modtab *mp;
  FILE *fp_radioC = fopen(radioC, "w");

  if (fp_radioC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", radioC);
    exit(1);
  }

  fprintf(fp_radioC, "/* Swift Fox generated code for Fennec Fox Radio configuration */\n");
  fprintf(fp_radioC, "\n#include <Fennec.h>\n\n");
  fprintf(fp_radioC, "configuration RadioC {\n");
  fprintf(fp_radioC, "  provides interface Mgmt;\n");
  fprintf(fp_radioC, "  provides interface RadioCall;\n");
  fprintf(fp_radioC, "  provides interface RadioSignal;\n");
  fprintf(fp_radioC, "}\n\n");
  fprintf(fp_radioC, "implementation {\n\n");
  fprintf(fp_radioC, "  components RadioP;\n");
  fprintf(fp_radioC, "  Mgmt = RadioP;\n");
  fprintf(fp_radioC, "  RadioCall = RadioP;\n");
  fprintf(fp_radioC, "  RadioSignal = RadioP;\n\n");
  fprintf(fp_radioC, "  components CachesC;\n");
  fprintf(fp_radioC, "  RadioP.ConfigurationCache -> CachesC;\n");
  fprintf(fp_radioC, "  CachesC.Radio -> RadioP;\n\n");
  fprintf(fp_radioC, "  /* Defined and linked radios */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioC, "\n  components new %sRadioC%s as %s_%d_RadioC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_radioC, "  RadioP.%s_%d_Control -> %s_%d_RadioC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_radioC, "  RadioP.%s_%d_Call -> %s_%d_RadioC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_radioC, "  RadioP.%s_%d_Signal -> %s_%d_RadioC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_radioC, "  CachesC.%s_%s_%d -> %s_%d_RadioC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioC, "\n}\n");
  fclose(fp_radioC);
}

void generateRadioP() {

  struct modtab *mp;
  FILE *fp_radioM = fopen(radioM, "w");

  if (fp_radioM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", radioM);
    exit(1);
  }

  fprintf(fp_radioM, "/* Swift Fox generated code for Fennec Fox Radio module */\n");
  fprintf(fp_radioM, "\n#include <Fennec.h>\n");
  fprintf(fp_radioM, "module RadioP {\n\n");
  fprintf(fp_radioM, "  provides interface Mgmt;\n");
  fprintf(fp_radioM, "  provides interface Module;\n");
  fprintf(fp_radioM, "  provides interface RadioCall;\n");
  fprintf(fp_radioM, "  provides interface RadioSignal;\n");
  fprintf(fp_radioM, "  uses interface ConfigurationCache;\n\n");
  fprintf(fp_radioM, "  /* Defined and linked radios */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "\n  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "  uses interface RadioCall as %s_%d_Call;\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "  uses interface RadioSignal as %s_%d_Signal;\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"\n}\n\n");
  fprintf(fp_radioM,"implementation {\n\n");
  fprintf(fp_radioM,"  uint8_t last_module_id;\n");
  fprintf(fp_radioM,"  void setLibrary(bool flag);\n");
  fprintf(fp_radioM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_radioM,"    last_module_id = 0;\n");
  fprintf(fp_radioM,"    setLibrary(ON);\n");
  fprintf(fp_radioM,"    return SUCCESS;\n");
  fprintf(fp_radioM,"  }\n\n");
  fprintf(fp_radioM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_radioM,"    last_module_id = 0;\n");
  fprintf(fp_radioM,"    setLibrary(OFF);\n");
  fprintf(fp_radioM,"    return SUCCESS;\n");
  fprintf(fp_radioM,"  }\n\n");
  fprintf(fp_radioM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_radioM,"    last_module_id = call ConfigurationCache.next_module(F_RADIO, last_module_id);\n");
  fprintf(fp_radioM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_radioM, "        break;\n\n");
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n\n");

  fprintf(fp_radioM,"  command error_t RadioCall.load(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    msg->len += sizeof(nx_struct fennec_header);\n");
  fprintf(fp_radioM,"    msg->fennec.len = msg->len;\n");
  fprintf(fp_radioM,"    memcpy(&msg->data, &msg->fennec, sizeof(nx_struct fennec_header));\n");
  fprintf(fp_radioM,"    msg->last_layer = F_MAC;\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return call %s_%d_Call.load(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return FAIL;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  fprintf(fp_radioM,"  command error_t RadioCall.send(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    msg->last_layer = F_MAC;\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return call %s_%d_Call.send(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return FAIL;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  fprintf(fp_radioM,"  command error_t RadioCall.resend(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    msg->last_layer = F_MAC;\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return call %s_%d_Call.resend(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return FAIL;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  fprintf(fp_radioM,"  command error_t RadioCall.sampleCCA(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return call %s_%d_Call.sampleCCA(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return FAIL;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  fprintf(fp_radioM,"  command uint8_t RadioCall.getMaxSize(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    msg->last_layer = F_MAC;\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return (call %s_%d_Call.getMaxSize(msg) - sizeof(nx_struct fennec_header));\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return 0;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  fprintf(fp_radioM,"  command uint8_t* RadioCall.getPayload(msg_t *msg) {\n\n");
  fprintf(fp_radioM,"    msg->last_layer = F_MAC;\n\n");
  fprintf(fp_radioM,"    switch (call ConfigurationCache.get_protocol(F_RADIO, msg)) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "      case %d:\n", mp->id);
      fprintf(fp_radioM, "        return (call %s_%d_Call.getPayload(msg) + sizeof(nx_struct fennec_header));\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_radioM,"      default:\n");
  fprintf(fp_radioM,"        return NULL;\n");
  fprintf(fp_radioM,"    }\n");
  fprintf(fp_radioM,"  }\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_RADIO) {
      fprintf(fp_radioM, "  event void %s_%d_Control.startDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    setLibrary(ON);\n");
      fprintf(fp_radioM, "  }\n\n");
      fprintf(fp_radioM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    setLibrary(OFF);\n");
      fprintf(fp_radioM, "  }\n\n");
      fprintf(fp_radioM, "  event void %s_%d_Signal.sendDone(msg_t *msg, error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    signal RadioSignal.sendDone(msg, err);\n");
      fprintf(fp_radioM, "  }\n\n");
      fprintf(fp_radioM, "  event void %s_%d_Signal.loadDone(msg_t *msg, error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    signal RadioSignal.loadDone(msg, err);\n");
      fprintf(fp_radioM, "  }\n\n");
      fprintf(fp_radioM, "  event void %s_%d_Signal.receive(msg_t *msg, uint8_t *payload, uint8_t len) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    signal RadioSignal.receive(msg, payload, len);\n");
      fprintf(fp_radioM, "  }\n\n");
      fprintf(fp_radioM, "  async event bool %s_%d_Signal.check_destination(msg_t *msg, uint8_t *payload) {\n", mp->lib->name, mp->id);
      fprintf(fp_radioM, "    return signal RadioSignal.check_destination(msg, payload + sizeof(nx_struct fennec_header));\n");
      fprintf(fp_radioM, "  }\n\n");
    }
  }

  fprintf(fp_radioM, "\n}\n");
  fclose(fp_radioM);
}

