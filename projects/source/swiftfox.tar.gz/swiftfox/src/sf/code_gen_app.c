/*
 * Copyright (c) 2010 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateApplicationC() {

  struct modtab *mp;
  FILE *fp_appC = fopen(appC, "w");

  if (fp_appC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", appC);
    exit(1);
  }

  fprintf(fp_appC, "/* Swift Fox generated code for Fennec Fox Application configuration */\n");
  fprintf(fp_appC, "\n#include <Fennec.h>\n\n");
  fprintf(fp_appC, "configuration ApplicationC {\n");
  fprintf(fp_appC, "  provides interface Mgmt;\n");
  fprintf(fp_appC, "}\n\n");
  fprintf(fp_appC, "implementation {\n\n");
  fprintf(fp_appC, "  components ApplicationP;\n");
  fprintf(fp_appC, "  Mgmt = ApplicationP;\n");
  fprintf(fp_appC, "  components CachesC;\n");
  fprintf(fp_appC, "  ApplicationP.ConfigurationCache -> CachesC;\n\n");
  fprintf(fp_appC, "  CachesC.Application -> ApplicationP;\n\n");
  fprintf(fp_appC, "  components NetworkC;\n");
  fprintf(fp_appC, "  ApplicationP.NetworkSignal -> NetworkC;\n\n");
  fprintf(fp_appC, "  /* Defined and linked applications */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appC, "\n  components new %sAppC%s as %s_%d_AppC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_appC, "  ApplicationP.%s_%d_Control -> %s_%d_AppC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_appC, "  ApplicationP.%s_%d_Signal <- %s_%d_AppC.NetworkSignal;\n\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_appC, "  NetworkC.NetworkCall <- %s_%d_AppC.NetworkCall;\n", mp->lib->name, mp->id);
      fprintf(fp_appC, "  CachesC.%s_%s_%d -> %s_%d_AppC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_appC, "\n}\n");
  fclose(fp_appC);
}

void generateApplicationP() {

  struct modtab *mp;
  FILE *fp_appM = fopen(appM, "w");

  if (fp_appM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", appM);
    exit(1);
  }

  fprintf(fp_appM, "/* Swift Fox generated code for Fennec Fox Application module */\n");
  fprintf(fp_appM, "\n#include <Fennec.h>\n\n");
  fprintf(fp_appM, "module ApplicationP {\n\n");
  fprintf(fp_appM, "  provides interface Mgmt;\n");
  fprintf(fp_appM, "  provides interface Module;\n");
  fprintf(fp_appM, "  uses interface NetworkSignal;\n");
  fprintf(fp_appM, "  uses interface ConfigurationCache;\n");


  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appM, "  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
      fprintf(fp_appM, "  provides interface NetworkSignal as %s_%d_Signal;\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_appM,"\n}\n\n");
  fprintf(fp_appM,"implementation {\n\n");
  fprintf(fp_appM,"  uint8_t last_module_id;\n");
  fprintf(fp_appM,"  void setLibrary(bool flag);\n");
  fprintf(fp_appM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_appM,"    last_module_id = 0;\n");
  fprintf(fp_appM,"    setLibrary(ON);\n");
  fprintf(fp_appM,"    return SUCCESS;\n");
  fprintf(fp_appM,"  }\n\n");
  fprintf(fp_appM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_appM,"    last_module_id = 0;\n");
  fprintf(fp_appM,"    setLibrary(OFF);\n");
  fprintf(fp_appM,"    return SUCCESS;\n");
  fprintf(fp_appM,"  }\n\n");
  fprintf(fp_appM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_appM,"    last_module_id = call ConfigurationCache.next_module(F_APPLICATION, last_module_id);\n");
  fprintf(fp_appM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appM, "      case %d:\n", mp->id);
      fprintf(fp_appM, "        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_appM, "        break;\n\n");
    }
  }

  fprintf(fp_appM,"      default:\n");
  fprintf(fp_appM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_appM,"    }\n");
  fprintf(fp_appM,"  }\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appM, "  event void %s_%d_Control.startDone(error_t err){\n", mp->lib->name, mp->id);
      fprintf(fp_appM, "    setLibrary(ON);\n");
      fprintf(fp_appM, "  }\n\n");
      fprintf(fp_appM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_appM, "    setLibrary(OFF);\n");
      fprintf(fp_appM, "  }\n\n");
    }
  }

  fprintf(fp_appM, "  void sendDone(msg_t *msg, error_t error) {\n");
  fprintf(fp_appM, "    switch( call ConfigurationCache.get_protocol(F_APPLICATION, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appM, "      case %d:\n", mp->id);
      fprintf(fp_appM, "        signal %s_%d_Signal.sendDone(msg, error);\n", mp->lib->name, mp->id);
      fprintf(fp_appM, "        break;\n\n");
    }
  }

  fprintf(fp_appM, "      default:\n");
  fprintf(fp_appM, "        break;\n");
  fprintf(fp_appM, "    }\n");
  fprintf(fp_appM, "  }\n\n");

  fprintf(fp_appM, "  void receive(msg_t *msg, uint8_t *payload, uint8_t len) {\n");
  fprintf(fp_appM, "    switch( call ConfigurationCache.get_protocol(F_APPLICATION, msg) ) {\n\n");
  fprintf(fp_appM,"      case 0:\n");
  fprintf(fp_appM,"        signal Module.drop_message(msg);\n\n");
  fprintf(fp_appM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_APPLICATION) {
      fprintf(fp_appM, "      case %d:\n", mp->id);
      fprintf(fp_appM, "        signal %s_%d_Signal.receive(msg, payload, len);\n", mp->lib->name, mp->id);
      fprintf(fp_appM, "        break;\n\n");
    }
  }

  fprintf(fp_appM,"      default:\n");
  fprintf(fp_appM,"        signal Module.drop_message(msg);\n\n");
  fprintf(fp_appM,"        break;\n");
  fprintf(fp_appM,"    }\n");
  fprintf(fp_appM, "  }\n\n");

  fprintf(fp_appM, "  event void NetworkSignal.sendDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_appM, "    sendDone(msg, err);\n");
  fprintf(fp_appM, "  }\n\n");
  fprintf(fp_appM, "  event void NetworkSignal.receive(msg_t *msg, uint8_t* payload, uint8_t len) {\n");
  fprintf(fp_appM, "    receive(msg, payload, len);\n");
  fprintf(fp_appM, "  }\n\n");

  fprintf(fp_appM, "\n}\n");
  fclose(fp_appM);
}

