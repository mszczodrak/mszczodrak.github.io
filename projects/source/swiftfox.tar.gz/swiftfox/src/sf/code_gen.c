/* Swift Fox Compiler v0.3
 * Authors: Marcin Szczodrak
 * Date: May 27, 2010
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "sf.h"
#include "code_gen.h"
#include "y.tab.h"

char *appC = NULL;
char *netC = NULL;
char *qoiC = NULL;
char *macC = NULL;
char *radioC = NULL;
char *eventC = NULL;
char *app_netC = NULL;
char *net_macC = NULL;
char *mac_radioC = NULL;
char *addrC = NULL;

char *appM = NULL;
char *netM = NULL;
char *qoiM = NULL;
char *macM = NULL;
char *radioM = NULL;
char *eventM = NULL;
char *app_netM = NULL;
char *net_macM = NULL;
char *mac_radioM = NULL;
char *addrM = NULL;

char *cachesC = NULL;
char *cachesM = NULL;

char *fex = NULL;

FILE* tmp_confs = NULL;
int policy_conf_id = -1;

void setFiles() {

  char *fennec_fox_lib = getenv("FENNEC_FOX_LIB");

  if (fennec_fox_lib == NULL) {
    fprintf(stderr, "\n\nFENNEC_FOX_LIB is not set!\n");
    exit(1);
  }

  char *p_appC = "Application/ApplicationC.nc";		
  char *p_appM = "Application/ApplicationP.nc";		
  appC = malloc(strlen(p_appC)+strlen(fennec_fox_lib)+2);
  sprintf(appC, "%s/%s", fennec_fox_lib, p_appC);
  appM = malloc(strlen(p_appM)+strlen(fennec_fox_lib)+2);
  sprintf(appM, "%s/%s", fennec_fox_lib, p_appM);

  char *p_netC = "Network/NetworkC.nc";
  char *p_netM = "Network/NetworkP.nc";
  netC = malloc(strlen(p_netC)+strlen(fennec_fox_lib)+2);
  sprintf(netC, "%s/%s", fennec_fox_lib, p_netC);
  netM = malloc(strlen(p_netM)+strlen(fennec_fox_lib)+2);
  sprintf(netM, "%s/%s", fennec_fox_lib, p_netM);

  char *p_qoiC = "QoI/QoIC.nc";
  char *p_qoiM = "QoI/QoIP.nc";
  qoiC = malloc(strlen(p_qoiC)+strlen(fennec_fox_lib)+2);
  sprintf(qoiC, "%s/%s", fennec_fox_lib, p_qoiC);
  qoiM = malloc(strlen(p_qoiM)+strlen(fennec_fox_lib)+2);
  sprintf(qoiM, "%s/%s", fennec_fox_lib, p_qoiM);

  char *p_macC = "Mac/MacC.nc";
  char *p_macM = "Mac/MacP.nc";
  macC = malloc(strlen(p_macC)+strlen(fennec_fox_lib)+2);
  sprintf(macC, "%s/%s", fennec_fox_lib, p_macC);
  macM = malloc(strlen(p_macM)+strlen(fennec_fox_lib)+2);
  sprintf(macM, "%s/%s", fennec_fox_lib, p_macM);

  char *p_radioC = "Radio/RadioC.nc";
  char *p_radioM = "Radio/RadioP.nc";
  radioC = malloc(strlen(p_radioC)+strlen(fennec_fox_lib)+2);
  sprintf(radioC, "%s/%s", fennec_fox_lib, p_radioC);
  radioM = malloc(strlen(p_radioM)+strlen(fennec_fox_lib)+2);
  sprintf(radioM, "%s/%s", fennec_fox_lib, p_radioM);

  char *p_addrC = "Addressing/AddressingC.nc";
  char *p_addrM = "Addressing/AddressingP.nc";
  addrC = malloc(strlen(p_addrC)+strlen(fennec_fox_lib)+2);
  sprintf(addrC, "%s/%s", fennec_fox_lib, p_addrC);
  addrM = malloc(strlen(p_addrM)+strlen(fennec_fox_lib)+2);
  sprintf(addrM, "%s/%s", fennec_fox_lib, p_addrM);

  char *p_eventC = "Events/EventsC.nc";
  char *p_eventM = "Events/EventsP.nc";
  eventC = malloc(strlen(p_eventC)+strlen(fennec_fox_lib)+2);
  sprintf(eventC, "%s/%s", fennec_fox_lib, p_eventC);
  eventM = malloc(strlen(p_eventM)+strlen(fennec_fox_lib)+2);
  sprintf(eventM, "%s/%s", fennec_fox_lib, p_eventM);

  char *p_cachesC = "Fennec/CachesC.nc";
  char *p_cachesM = "Fennec/CachesP.nc";
  cachesC = malloc(strlen(p_cachesC)+strlen(fennec_fox_lib)+2);
  sprintf(cachesC, "%s/%s", fennec_fox_lib, p_cachesC);
  cachesM = malloc(strlen(p_cachesM)+strlen(fennec_fox_lib)+2);
  sprintf(cachesM, "%s/%s", fennec_fox_lib, p_cachesM);
	
  char *p_fex = "support/sfc/fennec.extra";
  fex = malloc(strlen(p_fex)+strlen(fennec_fox_lib)+2);
  sprintf(fex, "%s/%s", fennec_fox_lib, p_fex);

  FILE *tmp = fopen(TEMP_CONF_FILE, "w");
  fclose(tmp);
}

void setFennecExtra() {

  FILE *fp_fe = fopen(fex, "w");

  if (fp_fe == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", fex);
    exit(1);
  }

  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/interfaces\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/libs\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/chips\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/system\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Fennec\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/ControlUnit\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/PowerMgmt\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Network\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/QoI\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Events\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Application\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Addressing\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Application/Dummy\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Mac\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Radio\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Sensors\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Serial\n");
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/tinyos-2.x\n");
  fprintf(fp_fe, "include $(FENNEC_FOX_LIB)/Sensors/sensors.extra\n");
  fprintf(fp_fe, "include $(FENNEC_FOX_LIB)/PowerMgmt/power.extra\n");
  fprintf(fp_fe, "include $(FENNEC_FOX_LIB)/libs/libs.extra\n");
  fprintf(fp_fe, "include $(FENNEC_FOX_LIB)/chips/chips.extra\n");

  /* just in case add tinyos radio for TOSSIM */
  fprintf(fp_fe, "CFLAGS+=-I$(FENNEC_FOX_LIB)/Radio/%s\n", "tinyos");

  struct modtab *mp;
  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->conf != NULL && mp->conf->counter > 0) {
      fprintf(fp_fe, "CFLAGS+=-I%s\n", mp->lib->path);
    }
  }

  struct libtab *lp;
  for(lp = libtab; lp < &libtab[NSYMS]; lp++) {
    if (lp->path && lp->used == 1) {
      fprintf(fp_fe, "CFLAGS+=-I%s\n", lp->path);
    }
  }

  fclose(fp_fe);
}

void finishCodeGeneration(int policy_counter) {
  int conf_counter = 0;
  int event_counter = 0;
  struct symtab *sp;

  for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
    if (sp->name) {
      if (!strcmp(sp->type, "event_id")) {
        event_counter++;
      }
      if (!strcmp(sp->type, "configuration_id")) {
        conf_counter++;
      }
    }
  }

  generateEvent();
  generateCaches(event_counter, policy_counter);

  generateApplicationC();
  generateNetworkC();
  generateQoIC();
  generateMacC();
  generateRadioC();
  generateEventC();
  generateAddressingC();

  generateApplicationP();
  generateNetworkP();
  generateQoIP();
  generateMacP();
  generateRadioP();
  generateEventP(event_counter);
  generateAddressingP();

  setFennecExtra();
}

/* Generate Events */

void generateEventC() {

  struct symtab *sp;
  FILE *fp_eventC = fopen(eventC, "w");

  if (fp_eventC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", eventC);
    exit(1);
  }

  fprintf(fp_eventC, "/* Swift Fox generated code for Fennec Fox Event configuration */\n");
  fprintf(fp_eventC, "\n#include <Fennec.h>\n\n");
  fprintf(fp_eventC, "configuration EventsC {\n");
  fprintf(fp_eventC, "  provides interface Mgmt;\n");
  fprintf(fp_eventC, "}\n\n");
  fprintf(fp_eventC, "implementation {\n\n");
  fprintf(fp_eventC, "  components EventsP;\n");
  fprintf(fp_eventC, "  Mgmt = EventsP;\n\n");
  fprintf(fp_eventC, "  components CachesC;\n");
  fprintf(fp_eventC, "  EventsP.EventCache -> CachesC;\n");
  fprintf(fp_eventC, "  /* Defined and linked event handlers */\n");

  for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
    if (sp->name && !strcmp(sp->type, "event_id")) {
      fprintf(fp_eventC, "\n  components new %sEventC() as %sEvent%dC;\n", sp->lib->name, sp->lib->name, sp->value);
      fprintf(fp_eventC, "  EventsP.%sEvent%d -> %sEvent%dC;\n", sp->lib->name, sp->value, sp->lib->name, sp->value);
    }
  }

  fprintf(fp_eventC, "\n}\n");
  fclose(fp_eventC);
}

void generateEventP(int event_counter) {

  struct symtab *sp;
  FILE *fp_eventM = fopen(eventM, "w");

  if (fp_eventM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", eventM);
    exit(1);
  }

  fprintf(fp_eventM, "/* Swift Fox generated code for Fennec Fox Event module */\n");
  fprintf(fp_eventM, "\n#include <Fennec.h>\n\n");
  fprintf(fp_eventM, "module EventsP {\n\n");
  fprintf(fp_eventM, "  provides interface Mgmt;\n");
  fprintf(fp_eventM, "  uses interface EventCache;\n");

  for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
    if (sp->name && !strcmp(sp->type, "event_id")) {
      fprintf(fp_eventM, "  uses interface Event as %sEvent%d;\n", sp->lib->name, sp->value);
    }
  }

  fprintf(fp_eventM, "\n}\n\n");
  fprintf(fp_eventM, "implementation {\n\n");
  fprintf(fp_eventM, "  void turnEvents(bool flag);\n");
  fprintf(fp_eventM, "  void setEvent(uint8_t ev_num, bool flag);\n\n");
  fprintf(fp_eventM, "  command error_t Mgmt.start() {\n");
  fprintf(fp_eventM, "    turnEvents(ON);\n");
  fprintf(fp_eventM, "    dbg(\"Events\", \"Events started\\n\");\n");
  fprintf(fp_eventM, "    signal Mgmt.startDone(SUCCESS);\n");
  fprintf(fp_eventM, "    return SUCCESS;\n");
  fprintf(fp_eventM, "  }\n\n");
  fprintf(fp_eventM, "  command error_t Mgmt.stop() {\n");
  fprintf(fp_eventM, "    turnEvents(OFF);\n");
  fprintf(fp_eventM, "    dbg(\"Events\", \"Events stopped\\n\");\n");
  fprintf(fp_eventM, "    signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_eventM, "    return SUCCESS;\n");
  fprintf(fp_eventM, "  }\n\n");
  fprintf(fp_eventM, "  void turnEvents(bool flag) {\n");
  fprintf(fp_eventM, "    uint8_t i;\n");
  fprintf(fp_eventM, "    for(i = 0 ; i < %d; i++ ) {\n", event_counter);
  fprintf(fp_eventM, "      if ( call EventCache.eventStatus(i)) {\n");
  fprintf(fp_eventM, "        setEvent(i + 1, flag);\n");
  fprintf(fp_eventM, "      }\n");
  fprintf(fp_eventM, "    }\n");
  fprintf(fp_eventM, "  }\n\n");
  fprintf(fp_eventM, "  void setEvent(uint8_t ev_num, bool flag) {\n\n");
  fprintf(fp_eventM, "    switch(ev_num) {\n\n");
  fprintf(fp_eventM, "      case 0:\n");
  fprintf(fp_eventM, "        break;\n\n");

  for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
    if (sp->name && !strcmp(sp->type, "event_id")) {
      fprintf(fp_eventM, "      case %d:\n", sp->value);
      fprintf(fp_eventM, "        flag ? call %sEvent%d.start(call EventCache.getEntry(%d)) : call %sEvent%d.stop();\n", sp->lib->name, sp->value, sp->value, sp->lib->name, sp->value);
      fprintf(fp_eventM, "        break;\n\n");
    }
  }

  fprintf(fp_eventM, "      default:\n");
  fprintf(fp_eventM, "        dbg(\"Events\", \"Events: there is no event with number %s\\n\", ev_num);\n", "%d");
  fprintf(fp_eventM, "    }\n");
  fprintf(fp_eventM, "  }\n\n");

  for(sp = symtab; sp < &symtab[NSYMS]; sp++) {
    if (sp->name && !strcmp(sp->type, "event_id")) {
      fprintf(fp_eventM, "  event void %sEvent%d.occured(bool oc) {\n", sp->lib->name, sp->value);
      fprintf(fp_eventM, "    oc ? call EventCache.setBit(%d) : call EventCache.clearBit(%d);\n", sp->value, sp->value);
      fprintf(fp_eventM, "  }\n\n");
    }
  }

  fprintf(fp_eventM, "\n}\n");
  fclose(fp_eventM);
}

char *relopToLetter(int i) {
  switch(i) {
    case LT:
      return "LT";
    case GT:
      return "GT";
    case LE:
      return "LE";
    case GE:
      return "GE";
    case NE:
      return "NE";
    case EQ:
      return "EQ";
    default:
      fprintf(stderr, "Unknown RELOP operator\n");
      exit(1);
    }
}
