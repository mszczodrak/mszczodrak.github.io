/*
 * Copyright (c) 2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   1/26/2011
 */

#include "code_gen.h"

void generateAddressingC() {

  struct modtab *mp;
  FILE *fp_addrC = fopen(addrC, "w");

  if (fp_addrC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", addrC);
    exit(1);
  }

  fprintf(fp_addrC, "/* Swift Fox generated code for Fennec Fox Addressing configuration */\n");
  fprintf(fp_addrC, "\n#include <Fennec.h>\n\n");
  fprintf(fp_addrC, "configuration AddressingC {\n");
  fprintf(fp_addrC, "  provides interface Mgmt;\n");
  fprintf(fp_addrC, "  provides interface Addressing[uint8_t layer];\n");
  fprintf(fp_addrC, "  uses interface MacCall;\n");
  fprintf(fp_addrC, "  uses interface MacSignal;\n");
  fprintf(fp_addrC, "}\n\n");
  fprintf(fp_addrC, "implementation {\n\n");
  fprintf(fp_addrC, "  components AddressingP;\n");
  fprintf(fp_addrC, "  Mgmt = AddressingP;\n");
  fprintf(fp_addrC, "  Addressing = AddressingP;\n");
  fprintf(fp_addrC, "  MacCall = AddressingP;\n");
  fprintf(fp_addrC, "  MacSignal = AddressingP;\n\n");
  fprintf(fp_addrC, "  components CachesC;\n");
  fprintf(fp_addrC, "  AddressingP.ConfigurationCache -> CachesC;\n\n");
  fprintf(fp_addrC, "  CachesC.Addressing -> AddressingP;\n\n");
  fprintf(fp_addrC, "  /* Defined and linked addressing */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrC, "\n  components new %sAddrC%s as %s_%d_AddrC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_addrC, "  AddressingP.%s_%d_Addressing -> %s_%d_AddrC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_addrC, "  AddressingP.%s_%d_Control -> %s_%d_AddrC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_addrC, "  CachesC.%s_%s_%d -> %s_%d_AddrC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrC, "\n}\n");
  fclose(fp_addrC);
}

void generateAddressingP() {

  struct modtab *mp;
  FILE *fp_addrM = fopen(addrM, "w");

  if (fp_addrM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", addrM);
    exit(1);
  }

  fprintf(fp_addrM, "/* Swift Fox generated code for Fennec Fox Addressing module */\n");
  fprintf(fp_addrM, "\n#include <Fennec.h>\n\n");
  fprintf(fp_addrM, "module AddressingP {\n\n");
  fprintf(fp_addrM, "  provides interface Mgmt;\n");
  fprintf(fp_addrM, "  provides interface Module;\n");
  fprintf(fp_addrM, "  provides interface Addressing[uint8_t layer];\n\n");
  fprintf(fp_addrM, "  uses interface ConfigurationCache;\n");
  fprintf(fp_addrM, "  uses interface MacCall;\n");
  fprintf(fp_addrM, "  uses interface MacSignal;\n");


  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM, "  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
      fprintf(fp_addrM, "  uses interface Addressing as %s_%d_Addressing;\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"}\n\n");
  fprintf(fp_addrM,"implementation {\n\n");
  fprintf(fp_addrM,"  uint8_t last_module_id;\n");
  fprintf(fp_addrM,"  void setLibrary(bool flag);\n");
  fprintf(fp_addrM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_addrM,"    last_module_id = 0;\n");
  fprintf(fp_addrM,"    setLibrary(ON);\n");
  fprintf(fp_addrM,"    return SUCCESS;\n");
  fprintf(fp_addrM,"  }\n\n");
  fprintf(fp_addrM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_addrM,"    last_module_id = 0;\n");
  fprintf(fp_addrM,"    setLibrary(OFF);\n");
  fprintf(fp_addrM,"    return SUCCESS;\n");
  fprintf(fp_addrM,"  }\n\n");
  fprintf(fp_addrM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_addrM,"    last_module_id = call ConfigurationCache.next_module(F_ADDRESSING, last_module_id);\n");
  fprintf(fp_addrM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_addrM,"        break;\n\n");
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command uint8_t Addressing.length[uint8_t layer](msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM, "        return call %s_%d_Addressing.length(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command nx_uint8_t* Addressing.addr[uint8_t layer](nx_uint16_t ad, msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        return call %s_%d_Addressing.addr(ad, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command bool Addressing.eq[uint8_t layer](nx_uint8_t *ad1, nx_uint8_t *ad2, msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        return call %s_%d_Addressing.eq(ad1, ad2, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command bool Addressing.copy[uint8_t layer](nx_uint8_t *pos, nx_uint16_t ad, msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        return call %s_%d_Addressing.copy(pos, ad, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command bool Addressing.move[uint8_t layer](nx_uint8_t *ad1, nx_uint8_t *ad2, msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        return call %s_%d_Addressing.move(ad1, ad2, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  async command bool Addressing.set[uint8_t layer](nx_uint8_t *pos, nx_uint16_t ad, msg_t *msg) {\n\n");
  fprintf(fp_addrM,"    switch( call ConfigurationCache.get_protocol(layer, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM,"      case %d:\n", mp->id);
      fprintf(fp_addrM,"        return call %s_%d_Addressing.set(pos, ad, msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_addrM,"      default:\n");
  fprintf(fp_addrM,"        return 0;\n");
  fprintf(fp_addrM,"    }\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  event void MacSignal.receive(msg_t *msg, uint8_t *payload, uint8_t len) {\n");
  fprintf(fp_addrM,"    signal Module.drop_message(msg);\n");
  fprintf(fp_addrM,"  }\n\n");

  fprintf(fp_addrM,"  event void MacSignal.sendDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_addrM,"    signal Module.drop_message(msg);\n");
  fprintf(fp_addrM,"  }\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_ADDRESS) {
      fprintf(fp_addrM, "  event void %s_%d_Control.startDone(error_t err){\n", mp->lib->name, mp->id);
      fprintf(fp_addrM, "    setLibrary(ON);\n");
      fprintf(fp_addrM, "  }\n\n");
      fprintf(fp_addrM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_addrM, "    setLibrary(OFF);\n");
      fprintf(fp_addrM, "  }\n\n");
    }
  }

  fprintf(fp_addrM, "\n}\n");
  fclose(fp_addrM);
}

