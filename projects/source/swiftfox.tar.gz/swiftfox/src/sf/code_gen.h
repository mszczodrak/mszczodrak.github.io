/* Swift Fox Compiler v0.2
 * Authors: Marcin Szczodrak
 * Date: May 9, 2010
 */

#ifndef __CODE_GEN_H__
#define __CODE_GEN_H__
#define TEMP_CONF_FILE	"/tmp/tmp_conf_file_sfc"

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "sf.h"
#include "traverse.h"

extern char *appC;
extern char *appM;

extern char *netC;
extern char *netM;

extern char *macC;
extern char *macM;

extern char *qoiC;
extern char *qoiM;

extern char *radioC;
extern char *radioM;

extern char *cachesC;
extern char *cachesM;

extern char *addrC;
extern char *addrM;

extern int conf_counter;
extern int app_id_counter;
extern int net_id_counter;
extern int mac_id_counter;
extern int qoi_id_counter;
extern int addr_id_counter;
extern int radio_id_counter;

extern FILE* tmp_confs;

void setFiles();
void setFennecExtra();

void finishCodeGeneration(int policy_counter);

void generateConfiguration(struct confnode* c);

void generateCaches(int event_counter, int policy_counter);
void generateEvent();

void generatePolicy(struct policy* p);
void generateInitial(struct initnode *i);

void generateApplicationC();
void generateNetworkC();
void generateQoIC();
void generateMacC();
void generateRadioC();
void generateEventC();
void generateAddressingC();

void generateApplicationP();
void generateNetworkP();
void generateMacP();
void generateQoIP();
void generateRadioP();
void generateEventP();
void generateAddressingP();

char *relopToLetter(int i);
#endif
