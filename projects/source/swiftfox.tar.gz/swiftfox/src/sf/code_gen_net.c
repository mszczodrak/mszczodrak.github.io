/*
 * Copyright (c) 2010-2011 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */
  
/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateNetworkC() {

  struct modtab *mp;
  FILE *fp_netC = fopen(netC, "w");

  if (fp_netC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", netC);
    exit(1);
  }

  fprintf(fp_netC, "/* Swift Fox generated code for Fennec Fox Network configuration */\n");
  fprintf(fp_netC, "\n#include <Timer.h>\n\n");
  fprintf(fp_netC, "configuration NetworkC {\n");
  fprintf(fp_netC, "  provides interface Mgmt;\n");
  fprintf(fp_netC, "  provides interface NetworkCall;\n");
  fprintf(fp_netC, "  provides interface NetworkSignal;\n");
  fprintf(fp_netC, "}\n\n");
  fprintf(fp_netC, "implementation {\n\n");
  fprintf(fp_netC, "  components NetworkP;\n");
  fprintf(fp_netC, "  Mgmt = NetworkP;\n");
  fprintf(fp_netC, "  NetworkCall = NetworkP;\n");
  fprintf(fp_netC, "  NetworkSignal = NetworkP;\n\n");
  fprintf(fp_netC, "  components MacC;\n");
  fprintf(fp_netC, "  NetworkP.MacSignal -> MacC;\n\n");
  fprintf(fp_netC, "  components CachesC;\n");
  fprintf(fp_netC, "  NetworkP.ConfigurationCache -> CachesC;\n\n");
  fprintf(fp_netC, "  CachesC.Network -> NetworkP;\n\n");
  fprintf(fp_netC, "  /* Control Unit */\n");
  fprintf(fp_netC, "  components ControlUnitC;\n");
  fprintf(fp_netC, "  NetworkP.ControlUnitMacSignal <- ControlUnitC.MacSignal;\n");
  fprintf(fp_netC, "  MacC.MacCall <- ControlUnitC.MacCall;\n\n");
  fprintf(fp_netC, "  /* Defined and linked network protocols */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netC, "\n  components new %sNetC%s as %s_%d_NetC;\n", mp->lib->name, mp->params, mp->lib->name, mp->id);
      fprintf(fp_netC, "  NetworkP.%s_%d_Control -> %s_%d_NetC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_netC, "  NetworkP.%s_%d_Call -> %s_%d_NetC;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_netC, "  NetworkP.%s_%d_NetSignal -> %s_%d_NetC.NetworkSignal;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_netC, "  NetworkP.%s_%d_MacSignal <- %s_%d_NetC.MacSignal;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_netC, "  MacC.MacCall <- %s_%d_NetC.MacCall;\n", mp->lib->name, mp->id);
      fprintf(fp_netC, "  CachesC.%s_%s_%d -> %s_%d_NetC.Module;\n", mp->type, mp->lib->name, mp->id, mp->lib->name, mp->id);
    }
  }

  fprintf(fp_netC, "\n}\n");
  fclose(fp_netC);
}

void generateNetworkP() {

  struct modtab *mp;
  FILE *fp_netM = fopen(netM, "w");

  if (fp_netM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", netM);
    exit(1);
  }

  fprintf(fp_netM, "/* Swift Fox generated code for Fennec Fox Network module */\n");
  fprintf(fp_netM, "\n#include <Fennec.h>\n");
  fprintf(fp_netM, "module NetworkP {\n\n");
  fprintf(fp_netM, "  provides interface Mgmt;\n");
  fprintf(fp_netM, "  provides interface Module;\n");
  fprintf(fp_netM, "  provides interface NetworkCall;\n");
  fprintf(fp_netM, "  provides interface NetworkSignal;\n");
  fprintf(fp_netM, "  uses interface ConfigurationCache;\n");
  fprintf(fp_netM, "  uses interface MacSignal;\n\n");
  fprintf(fp_netM, "  /* Control Unit */\n");
  fprintf(fp_netM, "  provides interface MacSignal as ControlUnitMacSignal;\n\n");
  fprintf(fp_netM, "  /* Defined and linked network protocols */\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "  uses interface Mgmt as %s_%d_Control;\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "  uses interface NetworkCall as %s_%d_Call;\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "  uses interface NetworkSignal as %s_%d_NetSignal;\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "  provides interface MacSignal as %s_%d_MacSignal;\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_netM,"}\n\n");
  fprintf(fp_netM,"implementation {\n\n");
  fprintf(fp_netM,"  uint8_t last_module_id;\n");
  fprintf(fp_netM,"  void setLibrary(bool flag);\n");
  fprintf(fp_netM,"  command error_t Mgmt.start() {\n");
  fprintf(fp_netM,"    last_module_id = 0;\n");
  fprintf(fp_netM,"    setLibrary(ON);\n");
  fprintf(fp_netM,"    return SUCCESS;\n");
  fprintf(fp_netM,"  }\n\n");
  fprintf(fp_netM,"  command error_t Mgmt.stop() {\n");
  fprintf(fp_netM,"    last_module_id = 0;\n");
  fprintf(fp_netM,"    setLibrary(OFF);\n");
  fprintf(fp_netM,"    return SUCCESS;\n");
  fprintf(fp_netM,"  }\n\n");
  fprintf(fp_netM,"  void setLibrary(bool flag) {\n\n");
  fprintf(fp_netM,"    last_module_id = call ConfigurationCache.next_module(F_NETWORK, last_module_id);\n");
  fprintf(fp_netM,"    switch(last_module_id) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        flag ? call %s_%d_Control.start() : call %s_%d_Control.stop() ;\n", mp->lib->name, mp->id, mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        flag ? signal Mgmt.startDone(SUCCESS) : signal Mgmt.stopDone(SUCCESS);\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM,"  }\n\n\n");

  fprintf(fp_netM,"  command error_t NetworkCall.send(msg_t *msg) {\n\n");
  fprintf(fp_netM,"    msg->last_layer = F_APPLICATION;\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        return call %s_%d_Call.send(msg);\n\n", mp->lib->name, mp->id);
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        return FAIL;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM, "  }\n\n");

  fprintf(fp_netM, "  command uint8_t* NetworkCall.getPayload(msg_t *msg) {\n\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        return call %s_%d_Call.getPayload(msg);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        return NULL;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM,"  }\n\n");

  fprintf(fp_netM, "  command uint8_t NetworkCall.getMaxSize(msg_t *msg) {\n\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        return call %s_%d_Call.getMaxSize(msg);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        return 0;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM, "  }\n\n");

  fprintf(fp_netM, "  command uint8_t* NetworkCall.getSource(msg_t *msg) {\n\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        return call %s_%d_Call.getSource(msg);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        return NULL;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM,"  }\n\n");

  fprintf(fp_netM, "  command uint8_t* NetworkCall.getDestination(msg_t *msg) {\n\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        return call %s_%d_Call.getDestination(msg);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        return NULL;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM,"  }\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "  event void %s_%d_Control.startDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "    setLibrary(ON);\n");
      fprintf(fp_netM, "  }\n");
      fprintf(fp_netM, "  event void %s_%d_Control.stopDone(error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "    setLibrary(OFF);\n");
      fprintf(fp_netM, "  }\n");
      fprintf(fp_netM, "  event void %s_%d_NetSignal.sendDone(msg_t *msg, error_t err) {\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "    signal NetworkSignal.sendDone(msg, err);\n");
      fprintf(fp_netM, "  }\n");
      fprintf(fp_netM, "  event void %s_%d_NetSignal.receive(msg_t *msg, uint8_t* payload, uint8_t len) {\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "    signal NetworkSignal.receive(msg, payload, len);\n");
      fprintf(fp_netM, "  }\n\n");
    }
  }

  fprintf(fp_netM,"  void sendDone(msg_t *msg, error_t error) {\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");
  fprintf(fp_netM,"      case 0:\n");
  fprintf(fp_netM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        signal %s_%d_MacSignal.sendDone(msg, error);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      case F_NETWORK_ADDRESSING:\n");
  fprintf(fp_netM,"      case F_MAC_ADDRESSING:\n");
  fprintf(fp_netM,"        //signal AddressingEvents.sendDone(msg, error);\n");
  fprintf(fp_netM,"        break;\n\n");

  fprintf(fp_netM,"      case POLICY_CONFIGURATION:\n");
  fprintf(fp_netM,"        signal ControlUnitMacSignal.sendDone(msg, error);\n");
  fprintf(fp_netM,"        break;\n\n");

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        break;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM, "  }\n\n");


  fprintf(fp_netM, "  void receive(msg_t *msg, uint8_t* payload, uint8_t len) {\n");
  fprintf(fp_netM,"    switch( call ConfigurationCache.get_protocol(F_NETWORK, msg) ) {\n\n");
  fprintf(fp_netM,"      case 0:\n");
  fprintf(fp_netM,"        signal Module.drop_message(msg);\n");
  fprintf(fp_netM,"        break;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0 && mp->lib->type == TYPE_NETWORK) {
      fprintf(fp_netM, "      case %d:\n", mp->id);
      fprintf(fp_netM, "        signal %s_%d_MacSignal.receive(msg, payload, len);\n", mp->lib->name, mp->id);
      fprintf(fp_netM, "        break;\n\n");
    }
  }

  fprintf(fp_netM,"      case F_NETWORK_ADDRESSING:\n");
  fprintf(fp_netM,"      case F_MAC_ADDRESSING:\n");
  fprintf(fp_netM,"        //signal AddressingEvents.receive(msg, payload, len);\n");
  fprintf(fp_netM,"        break;\n\n");

  fprintf(fp_netM,"      case POLICY_CONFIGURATION:\n");
  fprintf(fp_netM,"        signal ControlUnitMacSignal.receive(msg, payload, len);\n");
  fprintf(fp_netM,"        break;\n\n");

  fprintf(fp_netM,"      default:\n");
  fprintf(fp_netM,"        signal Module.drop_message(msg);\n");
  fprintf(fp_netM,"        break;\n");
  fprintf(fp_netM,"    }\n");
  fprintf(fp_netM, "  }\n\n");


  fprintf(fp_netM, "  event void MacSignal.sendDone(msg_t *msg, error_t err) {\n");
  fprintf(fp_netM, "    sendDone(msg, err);\n");
  fprintf(fp_netM, "  }\n\n");
  fprintf(fp_netM, "  event void MacSignal.receive(msg_t *msg, uint8_t* payload, uint8_t len) {\n");
  fprintf(fp_netM, "    receive(msg, payload, len);\n");
  fprintf(fp_netM, "  }\n\n");

  fprintf(fp_netM, "\n}\n");
  fclose(fp_netM);
}

