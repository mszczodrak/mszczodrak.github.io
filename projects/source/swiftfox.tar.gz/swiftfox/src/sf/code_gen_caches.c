/*
 * Copyright (c) 2010 Columbia University.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * - Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the
 *   distribution.
 * - Neither the name of the Columbia University nor the names of
 *   its contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL COLUMBIA
 * UNIVERSITY OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * author: Marcin Szczodrak
 * date:   12/31/2010
 */

#include "code_gen.h"

void generateCaches(int event_counter, int policy_counter) {

  struct modtab *mp;
  int i;
  FILE *tmp_confs = fopen(TEMP_CONF_FILE, "r");
  FILE *fp_cachesM = fopen(cachesM, "w");
  FILE *fp_cachesC = fopen(cachesC, "w");
  char temp_buffer[100];
  char* ffmodules[NUMBER_OF_FF_MODULES] = {"Application", "Network", "QoI", "Mac", "Radio", "Addressing", "ControlUnit"};

  if (fp_cachesM == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", cachesM);
    exit(1);
  }

  if (fp_cachesC == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", cachesC);
    exit(1);
  }

  if (tmp_confs == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", TEMP_CONF_FILE);
    exit(1);
  }

  fprintf(fp_cachesC, "/* Swift Fox generated code for Fennec Fox CachesC configuration */\n");
  fprintf(fp_cachesC, "configuration CachesC {\n\n");
  fprintf(fp_cachesC, "  provides interface SimpleStart;\n");
  fprintf(fp_cachesC, "  provides interface EventCache;\n");
  fprintf(fp_cachesC, "  provides interface PolicyCache;\n");
  fprintf(fp_cachesC, "  provides interface ConfigurationCache;\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0) {
      fprintf(fp_cachesC, "  uses interface Module as %s_%s_%d;\n", mp->type, mp->lib->name, mp->id);
    }
  }

  for(i = 0; i < NUMBER_OF_FF_MODULES; i++) {
    fprintf(fp_cachesC, "  uses interface Module as %s;\n", ffmodules[i]);
  }

  fprintf(fp_cachesC, "}\n\n");
  fprintf(fp_cachesC, "implementation {\n");
  fprintf(fp_cachesC, "  components CachesP;\n");
  fprintf(fp_cachesC, "  SimpleStart = CachesP;\n");
  fprintf(fp_cachesC, "  EventCache = CachesP;\n");
  fprintf(fp_cachesC, "  PolicyCache = CachesP;\n");
  fprintf(fp_cachesC, "  ConfigurationCache = CachesP;\n\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0) {
      fprintf(fp_cachesC, "  %s_%s_%d = CachesP.%s_%s_%d;\n", mp->type, mp->lib->name, mp->id, mp->type, mp->lib->name, mp->id);
    }
  }

  for(i = 0; i < NUMBER_OF_FF_MODULES; i++) {
    fprintf(fp_cachesC, "  %s = CachesP.%s;\n", ffmodules[i], ffmodules[i]);
  }

  fprintf(fp_cachesC, "\n  components MessageCacheC;\n");
  fprintf(fp_cachesC, "  CachesP.Memory->MessageCacheC;\n\n");
  fprintf(fp_cachesC, "}\n");

  fprintf(fp_cachesM, "/* Swift Fox generated code for Fennec Fox CachesM module */\n");
  fprintf(fp_cachesM, "\n#define NUMBER_OF_CONFIGURATIONS  %d\n", conf_counter);
  fprintf(fp_cachesM, "#define INTERNAL_POLICY_CONFIGURATION_ID  %d\n\n", policy_conf_id);
  fprintf(fp_cachesM, "#include <Fennec.h>\n\n");
  fprintf(fp_cachesM, "module CachesP @safe() {\n");
  fprintf(fp_cachesM, "  provides interface SimpleStart;\n");
  fprintf(fp_cachesM, "  provides interface EventCache;\n");
  fprintf(fp_cachesM, "  provides interface PolicyCache;\n");
  fprintf(fp_cachesM, "  provides interface ConfigurationCache;\n");
  fprintf(fp_cachesM, "  uses interface Memory<msg_t>;\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0) {
      fprintf(fp_cachesM, "  uses interface Module as %s_%s_%d;\n", mp->type, mp->lib->name, mp->id);
    }
  }

  for(i = 0; i < NUMBER_OF_FF_MODULES; i++) {
    fprintf(fp_cachesM, "  uses interface Module as %s;\n", ffmodules[i]);
  }

  fprintf(fp_cachesM, "}\n\n");
  fprintf(fp_cachesM, "implementation {\n\n");
  fprintf(fp_cachesM, "  nx_struct fennec_event eventsTable[%d];\n\n", event_counter);
  fprintf(fp_cachesM, "  uint8_t active_configuration;\n\n");
  fprintf(fp_cachesM, "  nx_struct fennec_configuration *configurations;\n\n");
  fprintf(fp_cachesM, "  nx_struct fennec_policy policies[%d];\n\n", policy_counter);
  fprintf(fp_cachesM, "  nx_uint8_t virtual_network_id;\n\n");
  fprintf(fp_cachesM, "  nx_struct accept_conf *accepting_configurations;\n\n");
  fprintf(fp_cachesM, "  nx_uint8_t accepting_conf_counter;\n\n");
  fprintf(fp_cachesM, "  nx_uint8_t accepting_resend_counter;\n\n");
  fprintf(fp_cachesM, "  bool control_unit_support;\n\n");
  fprintf(fp_cachesM, "  uint8_t get_protocol(uint8_t layer, uint8_t conf);\n\n");
  fprintf(fp_cachesM, "  nxle_uint16_t event_mask;\n\n");
  fprintf(fp_cachesM, "  void start();\n\n");
  fprintf(fp_cachesM, "  command void SimpleStart.start() {\n\n");
  fprintf(fp_cachesM, "    atomic {\n");
  fprintf(fp_cachesM, "      configurations = (nx_struct fennec_configuration *) malloc(sizeof(nx_struct fennec_configuration) * \n");
  fprintf(fp_cachesM, "        (NUMBER_OF_CONFIGURATIONS + NUMBER_OF_ACCEPTING_CONFIGURATIONS));\n\n");
  fprintf(fp_cachesM, "      accepting_configurations = (nx_struct accept_conf *) malloc(sizeof(nx_struct accept_conf) * \n");
  fprintf(fp_cachesM, "        (NUMBER_OF_ACCEPTING_CONFIGURATIONS));\n\n");
  fprintf(fp_cachesM, "      accepting_resend_counter = 0;\n\n");
  fprintf(fp_cachesM, "    }\n");

  fprintf(fp_cachesM, "    start();\n");
  fprintf(fp_cachesM, "    signal SimpleStart.startDone(SUCCESS);\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command nx_struct fennec_event *EventCache.getEntry(uint8_t ev) {\n");
  fprintf(fp_cachesM, "    return &eventsTable[--ev];\n");
  fprintf(fp_cachesM, "  }\n\n");
  fprintf(fp_cachesM, "  task void checkEvent() {\n");

  if (policy_counter > 0) {
  	fprintf(fp_cachesM, "    uint8_t i;\n");
	fprintf(fp_cachesM, "    for( i=0; i < %d; i++ ) {\n", policy_counter);
	fprintf(fp_cachesM, "      if (((policies[i].src_conf == ANY) || (policies[i].src_conf == active_configuration))\n");
	fprintf(fp_cachesM, "         && (policies[i].event_mask == event_mask)) {\n");
	fprintf(fp_cachesM, "        signal PolicyCache.newConf( policies[i].dst_conf );\n");
	fprintf(fp_cachesM, "      }\n");
	fprintf(fp_cachesM, "    }\n");
  }
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command uint8_t ConfigurationCache.next_module(uint8_t layer, uint8_t last_module_id) {\n");
  fprintf(fp_cachesM, "    uint8_t num_of_confs = 4;\n");
  fprintf(fp_cachesM, "    uint8_t module_ids[4] = {UNKNOWN_LAYER};\n");
  fprintf(fp_cachesM, "    uint8_t min_conf = UNKNOWN_LAYER;\n");
  fprintf(fp_cachesM, "    uint8_t i;\n\n");
  fprintf(fp_cachesM, "    switch(layer) {\n");
  fprintf(fp_cachesM, "      case F_APPLICATION:\n");
  fprintf(fp_cachesM, "      case F_NETWORK:\n");
  fprintf(fp_cachesM, "      case F_QOI:\n");
  fprintf(fp_cachesM, "        module_ids[0] = get_protocol(layer, active_configuration);\n");
  fprintf(fp_cachesM, "        break;\n\n");
  fprintf(fp_cachesM, "      case F_ADDRESSING:\n");
  fprintf(fp_cachesM, "        module_ids[0] = get_protocol(F_MAC_ADDRESSING, active_configuration);\n");
  fprintf(fp_cachesM, "        module_ids[1] = get_protocol(F_NETWORK_ADDRESSING, active_configuration);\n");
  fprintf(fp_cachesM, "        if (control_unit_support) {\n");
  fprintf(fp_cachesM, "          module_ids[2] = get_protocol(F_MAC_ADDRESSING, INTERNAL_POLICY_CONFIGURATION_ID);\n");
  fprintf(fp_cachesM, "          module_ids[3] = get_protocol(F_NETWORK_ADDRESSING, INTERNAL_POLICY_CONFIGURATION_ID);\n");
  fprintf(fp_cachesM, "        }\n");
  fprintf(fp_cachesM, "        break;\n\n");
  fprintf(fp_cachesM, "      case F_MAC:\n");
  fprintf(fp_cachesM, "      case F_RADIO:\n");
  fprintf(fp_cachesM, "        module_ids[0] = get_protocol(layer, active_configuration);\n");
  fprintf(fp_cachesM, "        if (control_unit_support) {\n");
  fprintf(fp_cachesM, "          module_ids[1] = get_protocol(layer, INTERNAL_POLICY_CONFIGURATION_ID);\n");
  fprintf(fp_cachesM, "        }\n");
  fprintf(fp_cachesM, "    }\n\n");
  fprintf(fp_cachesM, "    for (i = 0; i < num_of_confs; i++) {\n");
  fprintf(fp_cachesM, "      if ((module_ids[i] > last_module_id) && (module_ids[i] < min_conf)) {\n");
  fprintf(fp_cachesM, "        min_conf = module_ids[i];\n");
  fprintf(fp_cachesM, "      }\n");
  fprintf(fp_cachesM, "    }\n");
  fprintf(fp_cachesM, "    return min_conf;\n");
  fprintf(fp_cachesM, "  }\n");

  fprintf(fp_cachesM, "  uint8_t get_protocol(uint8_t layer, uint8_t conf) {\n\n");
  fprintf(fp_cachesM, "    if (conf == POLICY_CONFIGURATION) {\n");
  fprintf(fp_cachesM, "      if (layer == F_NETWORK) return conf;\n");
  fprintf(fp_cachesM, "      conf = INTERNAL_POLICY_CONFIGURATION_ID;\n");
  fprintf(fp_cachesM, "    }\n\n");
  fprintf(fp_cachesM, "    if (conf >= (NUMBER_OF_CONFIGURATIONS + accepting_conf_counter)) {\n");
  fprintf(fp_cachesM, "      return UNKNOWN_LAYER;\n");
  fprintf(fp_cachesM, "    }\n\n");
  fprintf(fp_cachesM, "    switch(layer) {\n\n");
  fprintf(fp_cachesM, "      case F_APPLICATION:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].application;\n\n");
  fprintf(fp_cachesM, "      case F_NETWORK:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].network;\n\n");
  fprintf(fp_cachesM, "      case F_QOI:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].qoi;\n\n");
  fprintf(fp_cachesM, "      case F_MAC:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].mac;\n\n");
  fprintf(fp_cachesM, "      case F_RADIO:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].radio;\n\n");
  fprintf(fp_cachesM, "      case F_NETWORK_ADDRESSING:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].net_addr;\n\n");
  fprintf(fp_cachesM, "      case F_MAC_ADDRESSING:\n");
  fprintf(fp_cachesM, "        return configurations[ conf ].mac_addr;\n\n");
  fprintf(fp_cachesM, "      default:\n");
  fprintf(fp_cachesM, "        dbg(\"ConfigurationCache\", \"ConfigurationCache Error: No such protocol typy\\n\");\n");
  fprintf(fp_cachesM, "        return UNKNOWN_LAYER;\n");
  fprintf(fp_cachesM, "    }\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command uint8_t ConfigurationCache.get_active_configuration(void) {\n");
  fprintf(fp_cachesM, "    return active_configuration;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  async command uint8_t ConfigurationCache.get_protocol(uint8_t layer, msg_t *msg) {\n");
  fprintf(fp_cachesM, "    uint8_t i;\n");
  fprintf(fp_cachesM, "    if (msg == NULL)\n");
  fprintf(fp_cachesM, "      return get_protocol(layer, active_configuration);\n\n");
  fprintf(fp_cachesM, "    if (msg->vnet_id == virtual_network_id)\n");
  fprintf(fp_cachesM, "      return get_protocol(layer, msg->fennec.conf);\n\n");
  fprintf(fp_cachesM, "    for(i = 0; i < accepting_conf_counter; i++) {\n");
  fprintf(fp_cachesM, "      if ((accepting_configurations[i].vnet_id == msg->vnet_id) &&\n");
  fprintf(fp_cachesM, "                (accepting_configurations[i].fennec.conf == msg->fennec.conf)) {\n");
  fprintf(fp_cachesM, "        return get_protocol(layer, accepting_configurations[i].local_conf);\n");
  fprintf(fp_cachesM, "      }\n");
  fprintf(fp_cachesM, "    }\n");
  fprintf(fp_cachesM, "    return get_protocol(layer, active_configuration);\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command error_t ConfigurationCache.set_active_configuration(uint8_t new_conf) {\n");
  fprintf(fp_cachesM, "    atomic active_configuration = new_conf;\n");
  fprintf(fp_cachesM, "    return SUCCESS;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command uint8_t ConfigurationCache.get_number_of_configurations() {\n");
  fprintf(fp_cachesM, "    return NUMBER_OF_CONFIGURATIONS;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command uint8_t ConfigurationCache.get_virtual_network_id() {\n");
  fprintf(fp_cachesM, "    return virtual_network_id;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command bool ConfigurationCache.add_configuration(nx_struct FFControl *conf_msg) {\n");
  fprintf(fp_cachesM, "    uint8_t *m = (uint8_t*) conf_msg;\n");
  fprintf(fp_cachesM, "    nx_struct fennec_configuration *fc = (nx_struct fennec_configuration*)\n");
  fprintf(fp_cachesM, "                                (m + sizeof(nx_struct FFControl));\n\n");
  fprintf(fp_cachesM, "    if (!accepting_conf_counter)\n");
  fprintf(fp_cachesM, "      return 1;\n\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].application = fc->application;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].network = fc->network;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].net_addr = fc->net_addr;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].qoi = fc->qoi;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].mac = fc->mac;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].mac_addr = fc->mac_addr;\n");
  fprintf(fp_cachesM, "    configurations[NUMBER_OF_CONFIGURATIONS + accepting_conf_counter].radio = fc->radio;\n\n");
  fprintf(fp_cachesM, "    accepting_configurations[accepting_conf_counter].fennec.conf = (nx_uint8_t) conf_msg->conf_id;\n");
  fprintf(fp_cachesM, "    accepting_configurations[accepting_conf_counter].vnet_id = (nx_uint8_t) conf_msg->vnet_id;\n");
  fprintf(fp_cachesM, "    accepting_configurations[accepting_conf_counter].local_conf = (nx_uint8_t) (NUMBER_OF_CONFIGURATIONS + accepting_conf_counter);\n");
  fprintf(fp_cachesM, "    atomic accepting_conf_counter++;\n");
  fprintf(fp_cachesM, "    return 0;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command void PolicyCache.control_unit_support(bool status) {\n\n");
  fprintf(fp_cachesM, "    control_unit_support = status;");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command bool PolicyCache.valid_policy_msg(nx_struct FFControl *policy_msg) {\n\n");
  fprintf(fp_cachesM, "    uint8_t i;\n");
  fprintf(fp_cachesM, "    if (policy_msg->conf_id >= NUMBER_OF_CONFIGURATIONS)\n");
  fprintf(fp_cachesM, "      return FALSE;\n\n");
  fprintf(fp_cachesM, "    if (policy_msg->vnet_id == virtual_network_id)\n");
  fprintf(fp_cachesM, "      return TRUE;\n\n");
  fprintf(fp_cachesM, "    for (i = 0; i < accepting_conf_counter; i++)\n");
  fprintf(fp_cachesM, "      if (accepting_configurations[i].fennec.conf == policy_msg->conf_id)\n");
  fprintf(fp_cachesM, "        return TRUE;\n\n");
  fprintf(fp_cachesM, "    return FALSE;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command uint8_t PolicyCache.add_accepts(nx_struct FFControl *conf) {\n\n");
  fprintf(fp_cachesM, "    if (accepting_resend_counter > 0) {\n");
  fprintf(fp_cachesM, "      /* Copy all acceptings to the configuration message */\n");
  fprintf(fp_cachesM, "      nx_uint8_t *m = &conf->accepts;\n");
  fprintf(fp_cachesM, "      m++;\n");
  fprintf(fp_cachesM, "      memcpy(m, accepting_configurations, accepting_conf_counter);\n\n");
  fprintf(fp_cachesM, "      /* Decrease the resend counter */\n");
  fprintf(fp_cachesM, "      accepting_resend_counter--;\n");
  fprintf(fp_cachesM, "      conf->accepts = accepting_conf_counter;\n");
  fprintf(fp_cachesM, "      return accepting_conf_counter + 1;\n");
  fprintf(fp_cachesM, "    } else {\n");
  fprintf(fp_cachesM, "      conf->accepts = 0;\n");
  fprintf(fp_cachesM, "      return 1;\n");
  fprintf(fp_cachesM, "    }\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  task void wrong_conf() {\n");
  fprintf(fp_cachesM, "    signal PolicyCache.wrong_conf();\n\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  inline bool check_configuration(msg_t *msg) @C() {\n");
  fprintf(fp_cachesM, "    if (POLICY_CONFIGURATION == msg->fennec.conf)\n");
  fprintf(fp_cachesM, "      return TRUE;\n\n");
  fprintf(fp_cachesM, "    if (NUMBER_OF_CONFIGURATIONS <= msg->fennec.conf)\n");
  fprintf(fp_cachesM, "      return FALSE;\n\n");
  fprintf(fp_cachesM, "    if (active_configuration == msg->fennec.conf)\n");
  fprintf(fp_cachesM, "      return TRUE;\n\n");
  fprintf(fp_cachesM, "    post wrong_conf();\n\n");
  fprintf(fp_cachesM, "    return FALSE;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command void EventCache.clearMask() {\n");
  fprintf(fp_cachesM, "    event_mask = 0;\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command void EventCache.setBit(uint16_t bit) {\n");
  fprintf(fp_cachesM, "    event_mask |= (1 << (bit - 1));\n");
  fprintf(fp_cachesM, "    post checkEvent();\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command void EventCache.clearBit(uint16_t bit) {\n");
  fprintf(fp_cachesM, "    event_mask &= ~(1 << (bit - 1));\n");
  fprintf(fp_cachesM, "    post checkEvent();\n");
  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  command bool EventCache.eventStatus(uint16_t event_num) {\n");

  if (policy_counter > 0) {
    fprintf(fp_cachesM, "    uint8_t i;\n");
    fprintf(fp_cachesM, "    for( i=0; i < %d; i++ ){\n", policy_counter);
    fprintf(fp_cachesM, "      if (((policies[i].src_conf == ANY) || (policies[i].src_conf == active_configuration)) &&\n");
    fprintf(fp_cachesM, "                                       (policies[i].event_mask & (1 << event_num))) {\n");
    fprintf(fp_cachesM, "        return 1;\n");
    fprintf(fp_cachesM, "      }\n");
    fprintf(fp_cachesM, "    }\n");
    fprintf(fp_cachesM, "    return 0;\n");
  } else {
    fprintf(fp_cachesM, "    return 0;\n");
  }

  fprintf(fp_cachesM, "  }\n\n");

  fprintf(fp_cachesM, "  void start() {\n");
  fprintf(fp_cachesM, "    atomic {\n");
  fprintf(fp_cachesM, "      virtual_network_id = 1;\n\n");
  fprintf(fp_cachesM, "      accepting_conf_counter = 0;\n\n");

  while (fgets(temp_buffer, 100, tmp_confs) != NULL) {
    fprintf(fp_cachesM, "%s", temp_buffer);
  }	

  fprintf(fp_cachesM, "    }\n");
  fprintf(fp_cachesM, "  }\n");

  for(mp = modtab; mp < &modtab[NSYMS]; mp++) {
    if (mp->lib != NULL && mp->lib->path && mp->id > 0) {
      fprintf(fp_cachesM, "\n  event uint8_t %s_%s_%d.get_conf() {\n", mp->type, mp->lib->name, mp->id);
      fprintf(fp_cachesM, "    return %d;\n", mp->id);
      fprintf(fp_cachesM, "  }\n");
      fprintf(fp_cachesM, "\n  event void %s_%s_%d.drop_message(msg_t* msg) {\n", mp->type, mp->lib->name, mp->id);
      fprintf(fp_cachesM, "    call Memory.put(msg);\n");
      fprintf(fp_cachesM, "  }\n");
      fprintf(fp_cachesM, "\n  event msg_t* %s_%s_%d.next_message() {\n", mp->type, mp->lib->name, mp->id);
      fprintf(fp_cachesM, "    msg_t *msg = (msg_t*) call Memory.get();\n");
      fprintf(fp_cachesM, "    nx_struct fennec_header *fennec;\n");
      fprintf(fp_cachesM, "    if (msg == NULL) return NULL;\n");
      fprintf(fp_cachesM, "    fennec = (nx_struct fennec_header*) &msg->data;\n");
      fprintf(fp_cachesM, "    fennec->conf = %d;\n", mp->id);
      fprintf(fp_cachesM, "    msg->fennec.conf = %d;\n", mp->id);
      fprintf(fp_cachesM, "    msg->vnet_id = virtual_network_id;\n");
      fprintf(fp_cachesM, "    return msg;\n");
      fprintf(fp_cachesM, "  }\n");
    }
  }

  for(i = 0; i < NUMBER_OF_FF_MODULES; i++) {
    fprintf(fp_cachesM, "\n  event uint8_t %s.get_conf() {\n", ffmodules[i]);
    if (strcmp(ffmodules[i], "ControlUnit")) {
      fprintf(fp_cachesM, "    return 0;\n");
    } else {
      fprintf(fp_cachesM, "    return POLICY_CONFIGURATION;\n");
    }
    fprintf(fp_cachesM, "  }\n");
    fprintf(fp_cachesM, "\n  event void %s.drop_message(msg_t* msg) {\n", ffmodules[i]);
    fprintf(fp_cachesM, "    call Memory.put(msg);\n");
    fprintf(fp_cachesM, "  }\n");
    fprintf(fp_cachesM, "\n  event msg_t* %s.next_message() {\n", ffmodules[i]);
    fprintf(fp_cachesM, "    msg_t *msg = (msg_t*) call Memory.get();\n");
    fprintf(fp_cachesM, "    nx_struct fennec_header *fennec;\n");
    fprintf(fp_cachesM, "    if (msg == NULL) return NULL;\n");
    fprintf(fp_cachesM, "    fennec = (nx_struct fennec_header*) &msg->data;\n");
    if (strcmp(ffmodules[i], "ControlUnit")) {
      fprintf(fp_cachesM, "    fennec->conf = %d;\n", 0);
      fprintf(fp_cachesM, "    msg->fennec.conf = %d;\n", 0);
    } else {
      fprintf(fp_cachesM, "    fennec->conf = POLICY_CONFIGURATION;\n");
      fprintf(fp_cachesM, "    msg->fennec.conf = POLICY_CONFIGURATION;\n");
    }
    fprintf(fp_cachesM, "    msg->vnet_id = virtual_network_id;\n");
    fprintf(fp_cachesM, "    return msg;\n");
    fprintf(fp_cachesM, "  }\n");
  }

  fprintf(fp_cachesM, "}\n");

  fclose(fp_cachesM);
  fclose(fp_cachesC);
  fclose(tmp_confs);
}

void generateConfiguration(struct confnode* c) {

  int conf_num = c->counter;
  FILE *tmp_confs = fopen(TEMP_CONF_FILE, "a");

  if (tmp_confs == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", TEMP_CONF_FILE);
    exit(1);
  }

  if (!strcmp(c->app->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].application = 0;\n", conf_num);
  } else {
    if (c->app->lib->id == 0) {
      c->app->lib->used = 1;
    }
    fprintf(tmp_confs, "      configurations[%d].application = %d;\n", conf_num, c->app->id);
  }

  if (!strcmp(c->net->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].network = 0;\n", conf_num);
  } else {
    if (c->net->lib->id == 0) {
      c->net->lib->used = 1;
    } 
    fprintf(tmp_confs, "      configurations[%d].network = %d;\n", conf_num, c->net->id);
  }

  if (!strcmp(c->net_addr->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].net_addr = 0;\n", conf_num);
  } else {
    if (c->net_addr->lib->id == 0) {
      c->net_addr->lib->used = 1;
    }
    fprintf(tmp_confs, "      configurations[%d].net_addr = %d;\n", conf_num, c->net_addr->id);
  }

  if (!strcmp(c->qoi->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].qoi = 0;\n", conf_num);
  } else {
    if (c->qoi->lib->id == 0) {
      c->qoi->lib->used = 1;
    } 
    fprintf(tmp_confs, "      configurations[%d].qoi = %d;\n", conf_num, c->qoi->id);
  }

  if (!strcmp(c->mac->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].mac = 0;\n", conf_num);
  } else {
    if (c->mac->lib->id == 0) {
      c->mac->lib->used = 1;
    } 
    fprintf(tmp_confs, "      configurations[%d].mac = %d;\n", conf_num, c->mac->id);
  }

  if (!strcmp(c->mac_addr->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].mac_addr = 0;\n", conf_num);
  } else {
    if (c->mac_addr->lib->id == 0) {
//      c->mac_addr->lib->id = addr_id_count;
//      addr_id_count++;
      c->mac_addr->lib->used = 1;
    }
    //fprintf(tmp_confs, "      configurations[%d].mac_addr = %d;\n", conf_num, c->mac_addr->lib->id);
    fprintf(tmp_confs, "      configurations[%d].mac_addr = %d;\n", conf_num, c->mac_addr->id);
  }

  if (!strcmp(c->radio->type, "keyword")) {
    fprintf(tmp_confs, "      configurations[%d].radio = 0;\n\n", conf_num);
  } else {
    if (c->radio->lib->id == 0) {
      c->radio->lib->used = 1;
    } 
    fprintf(tmp_confs, "      configurations[%d].radio = %d;\n\n", conf_num, c->radio->id);
  }
  fclose(tmp_confs);
}

void generateEvent() {

  FILE *tmp_confs = fopen(TEMP_CONF_FILE, "a");

  if (tmp_confs == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", TEMP_CONF_FILE);
    exit(1);
  }

  struct evtab *ev;
  for(ev = evtab; ev < &evtab[NEVS]; ev++) {
    if (ev->name) {
      fprintf(tmp_confs, "      eventsTable[%d].operation = %s;\n", ev->num-1, relopToLetter(ev->op));
      fprintf(tmp_confs, "      eventsTable[%d].value = %d;\n\n", ev->num-1, ev->value);
    } else {
      break;
    }
  }

  fclose(tmp_confs);
}

void generatePolicy(struct policy* p) {

  FILE *tmp_confs = fopen(TEMP_CONF_FILE, "a");

  if (tmp_confs == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", TEMP_CONF_FILE);
    exit(1);
  }

  int policy_num = p->counter;

  fprintf(tmp_confs, "      policies[%d].src_conf = %d;\n", policy_num, p->from->value);
  fprintf(tmp_confs, "      policies[%d].event_mask = %d;\n", policy_num, p->mask_l);
  fprintf(tmp_confs, "      policies[%d].dst_conf = %d;\n\n", policy_num, p->to->value);

  if (p->mask_r > -1) {
    ++policy_num;
    fprintf(tmp_confs, "      policies[%d].src_conf = %d;\n", policy_num, p->from->value);
    fprintf(tmp_confs, "      policies[%d].event_mask = %d;\n", policy_num, p->mask_r);
    fprintf(tmp_confs, "      policies[%d].dst_conf = %d;\n\n", policy_num, p->to->value);
  }

  fclose(tmp_confs);
}

void generateInitial(struct initnode *i) {

  FILE *tmp_confs = fopen(TEMP_CONF_FILE, "a");

  if (tmp_confs == NULL) {
    fprintf(stderr, "You do not have a permission to write into file: %s\n", TEMP_CONF_FILE);
    exit(1);
  }

  fprintf(tmp_confs, "      active_configuration = %d;\n\n", i->init);

  fclose(tmp_confs);
}
